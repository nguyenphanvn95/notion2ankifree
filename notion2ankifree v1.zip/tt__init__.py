"""Notion Sync plugin."""

import json
import zipfile
from collections import defaultdict
from pathlib import Path
from shutil import rmtree
from tempfile import TemporaryDirectory
from traceback import format_exc
from typing import Any, Dict, List, Optional, Set, cast
import datetime
from anki.collection import Collection
from aqt import mw
from aqt.gui_hooks import main_window_did_init
from aqt.utils import showCritical, showInfo
from jsonschema import ValidationError, validate
from PyQt6.QtCore import QObject, QRunnable, QThreadPool, QTimer, pyqtSignal
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QMenu, QMessageBox

from .anki_op_api import AnkiConnect
from .backend_auth import BackendServerError, UnvalidEmailOrPassword, User, UserInfo
from .deck_manager import DeckNotesManager
from .helpers import (
    BASE_DIR,
    enable_logging_to_file,
    get_logger,
    normalize_block_id,
    safe_path,
)
from .note_by_toggle import construct_anki_note_from_toggle
from .note_type_manager import MyNoteTypeManager
from .notion_client import NotionClient, NotionClientError
from .toggle_parser import (
    ToggleDetails,
    extract_notes_data,
)

from .seeting_gui import SettingsWidget


FREE_TOGGLES_LIMIT = 30
SYNCINTERVAL = 8  # hours

class AddOnConfig:
    def __init__(self):
        if not mw:
            return
        
        # Set debug mode True initially
        self.debug = True
        self.logger = get_logger(self.__class__.__name__, self.debug)

        # Load config
        config = mw.addonManager.getConfig(__name__)
        mw.addonManager.setConfigUpdatedAction(__name__, self.reload_config) # TODO: 存疑
        # Validate config
        self.config = self.get_valid_config(config)
        self.logger.info("Config loaded: %s", self.config)

        if not ("debug" in self.config and self.config["debug"]):
            self.logger.info("Debug mode is off")
            self.debug = False
            get_logger(self.__class__.__name__, self.debug)


    def reload_config(self, new_config: Optional[Dict[str, Any]]) -> None:
        """Reload configuration.

        :param new_config: new configuration
        """
        if not new_config:
            assert mw  # mypy
            new_config = mw.addonManager.getConfig(__name__)
        try:
            self._validate_config(new_config)
        except ValidationError as exc:
            self.logger.error("Config update error", exc_info=exc)
            showCritical(str(exc), title="Notion loader config update error")
        else:
            assert new_config  # mypy
            self.config = new_config

    def _validate_config(self, config: Optional[Dict[str, Any]]):
        """Validate config.

        :param config: config
        :raises ValidationError: if config is invalid
        """
        if not config:
            raise ValidationError("Config is empty")
        # Load schema and validate configuration
        with open(BASE_DIR / "schemas/config_schema.json", encoding="utf8") as s:
            schema = json.load(s)
        validate(config, schema)

    def get_valid_config(self, config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Get valid configuration.

        :param config: configuration
        :returns: either configuration provided (if it's valid) or default
            config
        """
        try:
            self._validate_config(config)
        except ValidationError as exc:
            showCritical(str(exc), title="Notion2Anki config read error")
            assert mw  # mypy
            default_config = mw.addonManager.addonConfigDefaults(str(BASE_DIR))
            return cast(Dict[str, Any], default_config)
        else:
            assert config  # mypy
            return config
        
    def update_config(self, new_config: Dict[str, Any]) -> None:
        """Update configuration.

        :param new_config: new configuration
        """
        try:
            self._validate_config(new_config)
        except ValidationError as exc:
            showCritical(str(exc), title="Notion2Anki config set error, config not updated")

        self.config.update(new_config)
        mw.addonManager.writeConfig(__name__, self.config)

        self.logger.info("Config updated: %s", self.config)
        

class NotionSyncPlugin(QObject):
    def __init__(self, config_obj: AddOnConfig):
        """Init plugin."""
        super().__init__()
        # While testing `mw` is None
        if not mw:
            return
        
        self.config_obj:AddOnConfig = config_obj

        # Create a logger
        self.debug = "debug" in self.config_obj.config and self.config_obj.config["debug"]
        self.logger = get_logger(self.__class__.__name__, self.debug)

        # Add actions to Tools menu
        # Add action to Anki menu
        self.notion_menu: Optional[QMenu] = None
        self.setting_widget: Optional[SettingsWidget] = None
        self.add_actions()

        self.logger.info("sd")

    def add_actions(self):
        """Add Notion menu entry with actions to Tools menu."""
        if not mw:
            self.logger.error("Main window (mw) is None")
            return
        self.notion_menu = mw.form.menuTools.addMenu("NotionSync")
        seeting_action = QAction("Setting", mw)
        about_action = QAction("About", mw)

        seeting_action.triggered.connect(self.show_settings)
        about_action.triggered.connect(self.show_about_dialog)

        self.notion_menu.addActions((seeting_action, about_action))

        self.logger.info("Actions added to Tools menu")

    def show_about_dialog(self):
        if not mw:
            self.logger.error("Main window (mw) is None")
            return
        message = "Notion Sync plugin for Anki"

        self.logger.info("About dialog")
        QMessageBox.about(mw, "About", message)

    def show_settings(self):
        """Show settings dialog."""
        if not mw:
            self.logger.error("Main window (mw) is None")
            return
        QMessageBox.about(mw, "Test", "Settings dialog should appear")
        self.setting_widget = SettingsWidget(self.config_obj)
        self.setting_widget.show()

enable_logging_to_file()
config_obj = AddOnConfig()
NotionSyncPlugin(config_obj)