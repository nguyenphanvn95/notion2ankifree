"""Helper functions."""

import json
import logging
import os
import platform
import re
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from jsonschema import ValidationError, validate


#: Plugin base dir
BASE_DIR = Path(__file__).parent
#: Block id regex
BLOCK_ID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")


def safe_path(original_path: Path) -> Path:
    """Get WinAPI path compatible with long paths if on Windows.

    :param original_path: original path
    :returns: WinAPI path on Windows or original path otherwise
    """
    if os.name != "nt":
        return original_path
    path = str(original_path.absolute())
    if path.startswith("\\\\"):
        path = f"\\\\?\\UNC\\{path[2:]}"
    else:
        path = f"\\\\?\\{path}"
    return Path(path)


def validate_config(config: Optional[Dict[str, Any]]):
    """Validate config.

    :param config: config
    :raises ValidationError: if config is invalid
    """
    if not config:
        raise ValidationError("Config is empty")
    # Load schema and validate configuration
    with open(BASE_DIR / "schemas/config_schema.json", encoding="utf8") as s:
        schema = json.load(s)
    validate(config, schema)


def enable_logging_to_file() -> None:
    """Enable logging to file."""
    root_logger = logging.getLogger("notion_sync")
    handler = logging.FileHandler(BASE_DIR / "log.txt", mode="w", encoding="utf8")
    formatter = logging.Formatter(
        fmt=("%(asctime)s - %(name)s - %(filename)s:%(lineno)d - " "%(levelname)s - %(message)s")
    )
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)


def get_logger(name: str, debug: bool = False) -> logging.Logger:
    """Create logger with proper handler and formatter.

    :param name: logger name
    :param debug: DEBUG logging level
    :returns: logger
    """
    logger = logging.getLogger(f"notion_sync.{name}")
    null_handler = logging.NullHandler()
    logger.addHandler(null_handler)
    level = logging.DEBUG if debug else logging.INFO
    logger.setLevel(level)
    return logger


def normalize_block_id(block_id: str) -> str:
    """Normalize Notion block id.

    I.e. 'd151217ae85f4e79a05406f7db2bb0da'
    -> 'd151217a-e85f-4e79-a054-06f7db2bb0da'

    :param block_id: Notion block id
    :returns: normalized block id
    """
    if not BLOCK_ID_RE.match(block_id):
        return f"{block_id[:8]}-{block_id[8:12]}-{block_id[12:16]}-" f"{block_id[16:20]}-{block_id[20:]}"
    return block_id


def safe_str(string: Optional[str]) -> str:
    """Get safe string for logging with system encoding.

    :param string: string to be sanitized
    :returns: sanitized string
    """
    if not string:
        return ""
    encoding = sys.getdefaultencoding()
    return string.encode(encoding, errors="backslashreplace").decode(encoding)


def print_toggles(toggles):
    for toggle in toggles:
        print("+ " * 20)
        print(f"summary:{toggle.summary}")
        print(f"content:{toggle.content}")
        print(f"page_src:{toggle.page_src}")
        print(f"toggle_src:{toggle.toggle_src}")
        print(f"tags:{toggle.tags}")
        if len(toggle.medias) > 0:
            print("medias:")
        for media in toggle.medias:
            print("-----------------")
            print(f" src:{media.src}")
            print(f" filename:{media.filename}")
            print(f" abs_path:{media.abs_path}")
            print(f" media_type:{media.media_type}")
            print(f" url:{media.url}")


def get_device_info():
    """获取设备信息，返回格式为 操作系统_设备名称"""
    try:
        platform_ = platform.system() + "-" + platform.release()
    except Exception as e:
        platform_ = "unknown"

    try:
        device_name = os.environ["COMPUTERNAME"]
    except Exception as e:
        device_name = "unknown"

    return platform_ + "_" + device_name
