import pathlib
from dataclasses import dataclass
from typing import List, Literal, Optional

from anki.consts import MODEL_CLOZE, MODEL_STD

from .helpers import BASE_DIR, get_logger
from .note_by_toggle import BaseAnkiNote, ClozeAnkiNote, StdAnkiNote


# 读取模板文件 和 css 文件
css_style = BASE_DIR.joinpath(pathlib.Path("styles/css/model.css")).read_text("utf-8")
std_front = BASE_DIR.joinpath(pathlib.Path("templates/std-front.html")).read_text("utf-8")
std_back = BASE_DIR.joinpath(pathlib.Path("templates/std-back.html")).read_text("utf-8")
cloze_front = BASE_DIR.joinpath(pathlib.Path("templates/cloze-front.html")).read_text("utf-8")
cloze_back = BASE_DIR.joinpath(pathlib.Path("templates/cloze-back.html")).read_text("utf-8")

# TODO: notion 的列表 在dark mode下看不清
# TODO: 公式会超出卡片


@dataclass
class MyCardTemplate:
    """Anki card template, 在anki官方文档中称为 card type. Front 和 Back 为html模板, 可以使用 {{字段名}} 插入字段.
    注: 此处的Front 和 Back 变量名可以是任意的, 但是html模板中的字段名必须和 order_fields 中的字段名一致."""

    Name: str  # 模板名
    Front: str  # html模板
    Back: str  # html模板


@dataclass
class MyModel:
    """Anki model, 在anki官方文档中称为 note type. order_fields 中的字段名必须和 card_templates 中的html模板中的字段名一致."""

    name: str
    order_fields: List[str]
    card_templates: List[MyCardTemplate]
    model_type: Literal[0, 1] = 0  # 0: MODEL_STD, 1: MODEL_CLOZE
    css_style: Optional[str] = None


class MyNoteTypeManager:
    def __init__(self, anki_api, debug=False):
        self.debug = debug
        self.logger = get_logger(self.__class__.__name__, debug)
        self.anki_api = anki_api
        self.note_types = {}
        self.note_types["cloze_model"] = MyModel(
            name="notion-anki-sync-cloze",
            order_fields=["Front", "Extra", "NotionLink", "ToggleLink"],
            card_templates=[MyCardTemplate(Name="Cloze 1", Front=cloze_front, Back=cloze_back)],
            model_type=MODEL_CLOZE,
            css_style=css_style,
        )
        self.note_types["std_model"] = MyModel(
            name="notion-anki-sync-std",
            order_fields=[
                "Front",
                "Back",
                "NotionLink",
                "ToggleLink",
            ],
            card_templates=[MyCardTemplate(Name="Question-Answer", Front=std_front, Back=std_back)],
            model_type=MODEL_STD,
            css_style=css_style,
        )

    def create_model(self, reset_note_type=False):
        for _, note_type in self.note_types.items():
            try:
                model_ = self.anki_api.getModel(note_type.name)
            except Exception:
                model_ = None

            if model_:
                if reset_note_type:
                    self.anki_api.removModelByModelName(note_type.name)
                    self.logger.info(f"Model '{note_type.name}' already exists, remove it")
                else:
                    self.logger.info(f"Model '{note_type.name}' already exists")
                    continue

            self.anki_api.createModel(
                modelName=note_type.name,
                inOrderFields=note_type.order_fields,
                cardTemplates=[i.__dict__ for i in note_type.card_templates],
                isCloze=note_type.model_type == MODEL_CLOZE,
                css=note_type.css_style,
            )
            self.logger.info(f"Create model '{note_type.name}'")

    def note_by_toggle_map_note_type_name(self, note_by_toggle: BaseAnkiNote):
        if isinstance(note_by_toggle, ClozeAnkiNote):
            return self.note_types["cloze_model"].name
        elif isinstance(note_by_toggle, StdAnkiNote):
            return self.note_types["std_model"].name
