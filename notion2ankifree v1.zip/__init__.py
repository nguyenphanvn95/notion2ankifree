"""Notion Sync plugin."""

import datetime
import json
import zipfile
from collections import defaultdict
from pathlib import Path
from shutil import rmtree
from tempfile import TemporaryDirectory
from traceback import format_exc
from typing import Any, Dict, List, Optional, Set, Union, cast

from anki.collection import Collection
from aqt import mw
from aqt.gui_hooks import main_window_did_init
from aqt.utils import showCritical, showInfo
from jsonschema import ValidationError, validate
from PyQt6.QtCore import QObject, QRunnable, QThreadPool, QTimer, pyqtSignal
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QMenu, QMessageBox

from .anki_op_api import AnkiConnect
from .deck_manager import DeckNotesManager
from .helpers import (
    BASE_DIR,
    enable_logging_to_file,
    get_device_info,
    get_logger,
    normalize_block_id,
    safe_path,
    validate_config,
)
from .note_by_toggle import construct_anki_note_from_toggle
from .note_type_manager import MyNoteTypeManager
from .notion_client import NotionClient, NotionClientError
from .seeting_gui import SettingsDialog
from .toggle_parser import (
    ToggleDetails,
    extract_notes_data,
)

enable_logging_to_file()

# --- Custom build: login/user features removed; all limits disabled ---
# (pages/notes/subdecks/intervals are unlimited in this build)
UNLIMITED_PAGE_NUM = 10**9
UNLIMITED_NOTE_NUM = 10**9

# Legacy names kept for compatibility (now unlimited)
UNLOGINED_PAGE_NUM = UNLIMITED_PAGE_NUM
NORMAL_PAGE_NUM = UNLIMITED_PAGE_NUM
UNLOGINED_NOTE_NUM = UNLIMITED_NOTE_NUM
NORMAL_NOTE_NUM = UNLIMITED_NOTE_NUM
NORMAL_SYNC_INTERVAL = 0


class NotionSyncPlugin(QObject):
    """Notion sync plugin.

    Reads config, handles signals from Anki and spawns synchronization tasks
    on timer.
    """

    #: Default sync interval, min
    DEFAULT_SYNC_INTERVAL: int = 30

    def __init__(self):
        """Init plugin."""
        super().__init__()
        # While testing `mw` is None
        if not mw:
            return

        # Load config
        config = mw.addonManager.getConfig(__name__)
        mw.addonManager.setConfigUpdatedAction(__name__, self.reload_config)
        # mw.addonManager.setConfigAction(__name__, self.show_setting_warning)
        # Validate config
        self.config = self.get_valid_config(config)

        # Create a logger
        self.debug = "debug" in self.config and self.config["debug"]
        if self.debug:
            enable_logging_to_file()
        self.logger = get_logger(self.__class__.__name__, self.debug)
        self.logger.info("Config loaded: %s", self.config)

        # user/login features removed in custom build
        self.user_manager = None
        self.user_info = None
        # Anki API
        self.anki_api: AnkiConnect = None

        # Note type manager
        self.note_type_manage: MyNoteTypeManager = None

        # The deck managers for each deck
        self.deck_managers: Optional[Dict[str, DeckNotesManager]] = None

        # The deck update info for each deck
        self.deck_update_info: Optional[Dict[str, Dict[str, int]]] = None

        # Create a thread for sync
        self.note_extract_thread_pool = QThreadPool()

        # 判断当前的同步是否是由定时器触发的
        self.is_auto_sync_flag = False

        # 创建 定时器
        self.timer: Optional[QTimer] = None  # 用来设置定时同步

        # Add action to Anki menu
        self.notion_menu: Optional[QMenu] = None
        self.add_actions()

        # main_window_did_init 任务
        main_window_did_init.append(self.handle_add_note_type)  # 创建note type

    def user_login(self):
        """Deprecated: user login removed in custom build."""
        return

    def show_setting_dialog(self):
        """Show settings dialog."""
        self.settings = SettingsDialog(
            parent=mw,
            config=self.config,
            addon_manager=self,
        )
        self.settings.show()

    def show_setting_warning(self):
        """当用户点击这个设置按钮时，弹出一个警告框，提示用户：请尽量不要使用此处的设置, 优先从 Tools -> Notion2Anki -> Setting 进行设置。"""
        showInfo("Please try to avoid using this setting, prefer to set it from Tools -> Notion2Anki -> Setting")

    def get_valid_config(self, config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Get valid configuration. 在最开始的时候，加载配置文件。

        :param config: configuration
        :returns: either configuration provided (if it's valid) or default
            config
        """
        # ---- config migration (custom build: no login/user fields) ----
        if config:
            removed = False
            for k in ("user_email", "user_password"):
                if k in config:
                    config.pop(k, None)
                    removed = True
            if removed:
                # Persist the cleaned config so schema validation won't fail next launch
                try:
                    mw.addonManager.writeConfig(__name__, config)
                except Exception:
                    pass
        # --------------------------------------------------------------

        try:
            validate_config(config)
        except ValidationError as exc:
            showCritical(str(exc), title="Notion loader config load error")
            assert mw  # mypy
            default_config = mw.addonManager.addonConfigDefaults(str(BASE_DIR))
            return cast(Dict[str, Any], default_config)
        else:
            assert config  # mypy
            return config

    def reload_config(self, new_config: Optional[Dict[str, Any]]) -> None:
        """Reload configuration.

        :param new_config: new configuration
        """
        if not new_config:
            assert mw  # mypy
            new_config = mw.addonManager.getConfig(__name__)
        try:
            validate_config(new_config)
        except ValidationError as exc:
            self.logger.error("Config update error", exc_info=exc)
            showCritical(str(exc), title="Notion loader config update error")
        else:
            assert new_config  # mypy
            self.config = new_config

    def add_actions(self):
        """Add Notion menu entry with actions to Tools menu."""
        assert mw  # mypy
        self.notion_menu = mw.form.menuTools.addMenu("Notion2Anki")
        setting_action = QAction("Setting", mw)
        about_action = QAction("About", mw)

        setting_action.triggered.connect(self.show_setting_dialog)
        about_action.triggered.connect(self.show_about_dialog)

        self.notion_menu.addActions((setting_action, about_action))

    def show_about_dialog(self):
        message = "Notion Sync plugin\n\n" "Version: 1.1.8 (20250910)"
        QMessageBox.about(mw, "About", message)

    def update_config(self, new_config):
        """Update configuration.

        :param new_config: new configuration
        """
        try:
            validate_config(new_config)
        except ValidationError as exc:
            showCritical(str(exc), title="Notion2Anki config set error")
            return

        self.config.update(new_config)
        mw.addonManager.writeConfig(__name__, self.config)
        self.logger.info(f"Config updated__{__name__}__:{self.config}")

        # 然后重新加载配置
        self.reload_config(new_config)

    def handle_logout(self):
        return

    def handle_login(self, *args, **kwargs):
        """Login is removed in this custom build."""
        from aqt.utils import showInfo
        showInfo('Login has been removed in this custom build. No account is required.', title='Notion2Anki')
        return

    def _handle_collection(self) -> None:
        assert mw
        self.collection = mw.col
        if not self.collection:
            self.logger.error("Collection is empty")

    def handle_add_note_type(self, reset_note_type=False):
        """Handle add note type. will be called after main window is initialized.
        TODO: 设置一个按钮，通过这个函数可以重置 notetype
        """
        self._handle_collection()
        if not self.collection:
            return

        # create anki api
        self.anki_api = AnkiConnect(collection=self.collection, window=mw)

        # create note type manager
        self.note_type_manager = MyNoteTypeManager(self.anki_api, debug=self.config["debug"])

        # create note type
        self.logger.info("Start creating note type")
        try:
            self.note_type_manager.create_model(reset_note_type=reset_note_type)
            self.logger.info("All Note type created")
        except Exception as e:
            self.logger.error("Error creating note type", exc_info=e)
            showCritical(str(e), title="note type creation error")
            return

    def get_notion_pages_config(self) -> List[List[str]]:
        """Get Notion pages configuration. For page_spec without a specified target_deck value, the target_deck will default to using the page_id.

        :returns: Notion pages configuration, including page_id, target_deck, recursive and absolute_update
        """
        pages_conf = []
        for page_spec in self.config.get("notion_pages", []):
            absolute_update = page_spec.get("absolute_update", False)
            incremental_update = page_spec.get("incremental_update", False)
            if not absolute_update and not incremental_update:
                continue

            ori_page_id = page_spec["page_id"]
            page_id = normalize_block_id(ori_page_id)
            target_deck = page_spec.get("target_deck", None)
            recursive = page_spec.get("recursive", False)
            if target_deck == "" or target_deck is None:
                target_deck = ori_page_id

            pages_conf.append([page_id, target_deck, recursive, absolute_update, incremental_update])

        # 等于0说明没有配置任何page，不用判断用户是否登录 or 登录用户是否有权限
        if len(pages_conf) == 0:
            return pages_conf

        if self._sync_user_status == "unlogined":
            if len(pages_conf) > 1 or (len(pages_conf) == 1 and "::" in pages_conf[0][1]):
                # 找第一个target_deck中没有 "::" 的 pages_conf 下标
                index = -1
                for i, page_conf in enumerate(pages_conf):
                    if "::" not in page_conf[1]:
                        index = i
                        break
                if index == -1:
                    msg = "Notion2Anki: Login is not required, or there is no allowed page to sync"
                else:
                    msg = (
                        f"Notion2Anki: Login is not required, or you only have permission to sync the following one page:<br>"
                        f"i.e. <b>{pages_conf[index][0]}</b> -> <b>{pages_conf[index][1]}</b>"
                    )
                msg += "<br><br>Do you want continue?"

                response = QMessageBox.question(
                    mw,
                    "Notion2Anki",
                    msg,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )

                if response == QMessageBox.StandardButton.Yes.value:
                    return pages_conf[index : index + 1] if index != -1 else []
                else:
                    return []

            else:
                return pages_conf

        # 登录但未授权的用户，只能同步 UNREDEEMED_PAGE_NUM 个page， 且不支持 subdeck
        if self._sync_user_status == "unredeemed":
            # 不支持 subdeck
            unvalid_deck_index = []
            for i, page_conf in enumerate(pages_conf):
                # 如果 target_deck 中有 "::"，那么就不支持；或者已经超过了未登录用户可以同步的数量
                if "::" in page_conf[1] or i - len(unvalid_deck_index) >= UNLIMITED_PAGE_NUM:
                    unvalid_deck_index.append(i)

            if len(unvalid_deck_index) > 0:
                # 构建消息内容
                msg = "Notion2Anki: You don't have permission to sync pages to theses subdecks:<ul>"
                temp_subdeck = {pages_conf[i][1] for i in unvalid_deck_index}  # 用来去重
                for sd_ in temp_subdeck:
                    msg += f"<li><b>{sd_}</b></li>"

                msg += "</ul>Please update your account to get permission."

                msg += "<br><br>Do you want to sync the rest of the pages?"

                response = QMessageBox.question(
                    mw,
                    "Notion2Anki",
                    msg,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )

                if response == QMessageBox.StandardButton.No.value:
                    return []

            return [pages_conf[i] for i in range(len(pages_conf)) if i not in unvalid_deck_index]

        return pages_conf

    def is_allowed_sync(self) -> Union[bool, int]:
        """Custom build: always allowed (no backend throttling)."""
        return True, 0

    def pre_sync(self):
        """执行同步前的一些事情. 根据配置文件, 创建deck manager, 且准备统计每一个deck的卡片情况"""
        self.deck_managers = {}
        self.deck_update_info = {}  # 统计每个deck的卡片同步细节
        self.deck_page_work_status = {}  # 统计每个deck-page的同步状态, deck和page_id 可能是多对多的关系
        self.existing_note_ids = {}  # 每个deck 中已经存在的note_id，用来控制绝对同步时删除一些note_id
        self.synced_note_ids = {}  # 每个deck 中由notion转过来的 note_id，用来控制绝对同步时删除一些note_id
        self._sync_errors = []  # 保存同步过程中的错误信息
        self._sync_warnings = []  # 保存同步过程中的警告信息
        self._ignore_notes = defaultdict(int)  # 保存同步过程中的忽略的note数量

        # Custom build: always treat as 'redeemed' and skip backend sync restrictions
        self._sync_user_status = 'redeemed'

        is_allow_sync, wait_time = True, 0

        if not is_allow_sync:
            self.cur_sync_notion_pages_config = []
            self.logger.info(
                "Sync not allowed due to sync interval restrictions, so set cur_sync_notion_pages_config to []"
            )
            showInfo(
                f"Sync not allowed due to sync interval restrictions, please wait for a while ({max(1, int(wait_time))} minutes) or update your account",
                title="Notion2Anki",
            )

            return

        # 仅在同步前获取一次，因为获取的时候会根据用户的权限来判断同步的deck
        self.cur_sync_notion_pages_config = self.get_notion_pages_config()
        for page_conf in self.cur_sync_notion_pages_config:
            page_id, target_deck, recursive, absolute_update, incremental_update = page_conf
            self.deck_managers[target_deck] = DeckNotesManager(target_deck, self.anki_api, self.config["debug"])
            self.deck_update_info[target_deck] = {
                "processed": 0,
                "updated": 0,
                "added": 0,
                "deleted": 0,
            }
            self.deck_page_work_status[f"{target_deck}-{page_id}"] = {
                "status": "pending",
                "error": None,
            }

            self.synced_note_ids[target_deck] = set()
            self.existing_note_ids[target_deck] = set(self.deck_managers[target_deck].existing_note_ids)

    def _sync(self):
        """Sync notes."""
        self.logger.info("Sync preprocessing")
        self.pre_sync()  # 每次同步前，都要初始化好deck manager, 且准备统计每一个deck的卡片情况
        if len(self.cur_sync_notion_pages_config) == 0:
            self.logger.info("No pages to sync")
            return

        self.logger.info("Sync preprocessing done, start syncing")

        self.notion_menu.setTitle("Notion2Anki (syncing...)")
        for page_conf in self.cur_sync_notion_pages_config:
            page_id, target_deck, recursive, absolute_update, incremental_update = page_conf
            self.logger.info(f"Starting worker for page: {page_id} in {target_deck}")

            worker = NotesExtractorWorker(
                notion_token=self.config["notion_token"],
                page_id=page_id,
                recursive=recursive,
                target_deck=target_deck,
                notion_namespace=self.config.get("notion_namespace", ""),
                debug=self.debug,
            )
            worker.signals.result.connect(self.handle_worker_result)
            worker.signals.error.connect(self.handle_worker_error)
            worker.signals.finished.connect(self.handle_sync_finished)
            # Start worker
            self.note_extract_thread_pool.start(worker)
            self.deck_page_work_status[f"{target_deck}-{page_id}"]["status"] = "running"

    def sync_statue(self) -> str:
        statue = "pending"

        # 如果当前类中没有deck_page_work_status，那么整个同步状态就是pending
        if not hasattr(self, "deck_page_work_status"):
            return statue

        # 只有有一个deck-page的状态是running，那么整个同步状态就是running
        for status_detail in self.deck_page_work_status.values():
            if status_detail["status"] == "running":
                statue = "running"
                break
        # 只有所有的deck-page的状态都是finished，那么整个同步状态就是finished
        statue = (
            "finished"
            if all(status_detail["status"] == "finished" for status_detail in self.deck_page_work_status.values())
            else statue
        )

        return statue

    def sync(self):
        """Perform synchronization and report result."""
        self.logger.info("Sync started")

        assert mw  # mypy
        if self.sync_statue() != "running":
            self._sync()
        else:
            showInfo(
                "Sync is already in progress, please wait",
                title="Notion2Anki",
            )

    def auto_sync(self) -> None:
        """Perform synchronization in background."""
        # 如果 self.timer 存在且已经激活，那么说明有一个定时器已经在运行了，不需要再次运行
        if self.timer and self.timer.isActive():
            # 如果定时器的时间间隔和配置文件中的一样，那么就不需要再次运行
            if self.timer.interval() == self.config["sync_every_minutes"] * 60 * 1000:
                return
            # 如果定时器的时间间隔和配置文件中的不一样，那么重新设置定时器的时间间隔
            else:
                self.timer.stop()
                self.timer.setInterval(self.config["sync_every_minutes"] * 60 * 1000)
                self.timer.start()
        else:
            self.timer = QTimer()
            self.timer.setInterval(self.config["sync_every_minutes"] * 60 * 1000)

            def temp_func():
                self.is_auto_sync_flag = True
                self.sync()

            self.timer.timeout.connect(temp_func)
            self.timer.start()

    def handle_worker_result(self, deck_page: str, toggles: List[ToggleDetails]) -> None:
        """Add notes to collection.

        :param deck_name: 卡组名称
        :param toggles: List[ToggleDetails] 从 Notion 中提取的toggle
        """
        deck_name, page_id = deck_page.split("-", 1)
        assert self.deck_managers and deck_name in self.deck_managers
        # Custom build: no page/note limits
        self.logger.info(f"Start converting {len(toggles)} toggles to notes: {deck_name}")

        try:
            for toggle in toggles:
                note_by_toggle = construct_anki_note_from_toggle(toggle)
                self.deck_update_info[deck_name]["processed"] += 1
                # 获取 该 note 对应的 note type, 即 模板类型
                model_name = self.note_type_manager.note_by_toggle_map_note_type_name(note_by_toggle)
                # 根据 note正面内容在 该卡组里面查找是否存在该 正面内容对应的 note
                try:
                    note_id = self.deck_managers[deck_name].find_note_by_front(note_by_toggle.Front)
                except Exception as e:
                    self.logger.error(
                        f"Error finding note: {note_by_toggle.Front}",
                        exc_info=e,
                    )
                    continue
                if note_id:
                    try:
                        self.deck_managers[deck_name].update_exist_anki_note(
                            ankinote_id=note_id,
                            note_by_toggle=note_by_toggle,
                            model_name=model_name,
                        )
                        self.deck_update_info[deck_name]["updated"] += 1
                    except Exception as e:
                        # 更新失败, 删除该 note, 重新创建
                        self.logger.error(
                            f"Error updating note: {note_id}, {note_by_toggle.Front}",
                            exc_info=e,
                        )

                        # 删除该 note，重新创建
                        self.deck_managers[deck_name].remove_notes([note_id])
                        try:
                            note_id = self.deck_managers[deck_name].create_new_anki_note(
                                note_by_toggle=note_by_toggle, model_name=model_name
                            )
                            self.deck_update_info[deck_name]["updated"] += 1
                        except Exception as e:
                            self.logger.error(
                                f"Error creating note: {note_by_toggle.Front}",
                                exc_info=e,
                            )
                # Create new note
                else:
                    try:
                        note_id = self.deck_managers[deck_name].create_new_anki_note(
                            note_by_toggle=note_by_toggle, model_name=model_name
                        )
                        self.deck_update_info[deck_name]["added"] += 1
                    except Exception as e:
                        self.logger.error(
                            f"Error creating note: {note_by_toggle.Front}",
                            exc_info=e,
                        )

                self.synced_note_ids[deck_name].add(note_id)

            # Custom build: no backend conversion record posting

        except Exception:
            error_msg = format_exc()
            self._sync_errors.append(error_msg)

    def handle_sync_finished(self, deck_page: str) -> None:
        """Handle sync finished.

        In case of any error - show error message in manual mode and do nothing
        otherwise.  If no error - save the collection and show sync statistics
        in manual mode.  If `self._remove_obsolete_on_sync` is True - remove
        all notes that is not added or updated in current sync.

        :param deck: deck name that finished sync (Only this deck is finished)
        """
        assert self.deck_managers
        deck_name, _ = deck_page.split("-", 1)
        assert self.collection  # mypy
        self.logger.info(f"Worker finished: {deck_name}")
        self.deck_page_work_status[deck_page]["status"] = "finished"

        # If all workers finished, execute following code in this function, otherwise wait
        for sync_details in self.deck_page_work_status.values():
            if sync_details["status"] != "finished":
                return

        assert self.notion_menu  # mypy
        self.notion_menu.setTitle("Notion2Anki")
        # Show errors if manual sync
        if self._sync_errors:
            error_msg = "\n".join(self._sync_errors)
            showCritical(error_msg, title="Loading from Notion failed")

        # If no errors - save collection and refresh Anki window
        else:
            # pass  # TODO 这里是要删除一些note_id的。对于绝对更新的卡组
            _visited_decks = set()
            need_to_remove_note_ids = defaultdict(set)
            need_to_remove_note_num = 0
            for page_conf in self.cur_sync_notion_pages_config:
                page_id, target_deck, recursive, absolute_update, incremental_update = page_conf
                # 这里会有 多个 page_id对同一个 target_deck的情况, 因此不对同样的 target_deck进行多次删除
                if absolute_update and target_deck not in _visited_decks:
                    need_to_remove_note_ids[target_deck].update(
                        self.existing_note_ids[target_deck] - self.synced_note_ids[target_deck]
                    )
                    need_to_remove_note_num += len(need_to_remove_note_ids)
                _visited_decks.add(target_deck)

            # 找到之后，开始准备删除

            if need_to_remove_note_num > 0:
                stats_table = "<table style='width: 100%; border-collapse: collapse; text-align: center;'>"
                stats_table += (
                    "<tr>"
                    "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Deck</th>"
                    "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Note</th>"
                    "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Num</th>"
                    "</tr>"
                )
                for deck_name, note_ids in need_to_remove_note_ids.items():
                    stats_table += "<tr>"
                    stats_table += f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center; vertical-align: middle;'>{deck_name}</td>"

                    note_front = []
                    for note_id in note_ids:
                        try:
                            temp_front = self.anki_api.getNote(note_id)["Front"]
                            note_front.append(temp_front)
                        except Exception:
                            note_front.append(str(note_id))
                    # 展示每个note的正面内容的前10个字符，然后用...代替。如果note的正面内容小于10个字符，那么就展示全部
                    note_front = [front[:8] + "..." if len(front) > 10 else front for front in note_front]

                    stats_table += f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: left; vertical-align: middle;'>{'<br>'.join(list(note_front))}</td>"

                    stats_table += f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center; vertical-align: middle;'>{len(note_front)}</td>"

                    stats_table += "</tr>"

                stats_table += "</table>"

                msg = f"Will delete the following obsolete note(s):   <br>{stats_table}"

                assert mw  # mypy
                do_delete = QMessageBox.question(
                    mw,
                    "Confirm deletion?",
                    msg,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )
                if do_delete == QMessageBox.StandardButton.Yes.value:
                    for deck_name, notes_id in need_to_remove_note_ids.items():
                        self.deck_managers[deck_name].remove_notes(list(notes_id))
                        self.logger.info(
                            f"Deleted notes(absolute_update): {deck_name}, count:{len(notes_id)}, note_ids:{notes_id}"
                        )
                        self.deck_update_info[deck_name]["deleted"] += len(notes_id)

        self.collection.save(trx=False)
        mw.maybeReset()  # type: ignore[union-attr]
        mw.deckBrowser.refresh()  # type: ignore[union-attr]
        # 同步完成后，用一张表展示各个deck的同步情况

        if not self.is_auto_sync_flag:
            stats = self.deck_update_info
            stats_table = "<table style='width: 100%; border-collapse: collapse; text-align: center;'>"
            stats_table += (
                "<tr>"
                "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Deck</th>"
                "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Processed</th>"
                "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Updated</th>"
                "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Added</th>"
                "<th style='padding: 8px; border-bottom: 2px solid black; border-top: 2px solid black;'>Deleted</th>"
                "</tr>"
            )
            for deck, info in stats.items():
                stats_table += (
                    f"<tr>"
                    f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center;'>{deck}</td>"
                    f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center;'>{info['processed']}</td>"
                    f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center;'>{info['updated']}</td>"
                    f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center;'>{info['added']}</td>"
                    f"<td style='padding: 8px; border-bottom: 1px solid black; text-align: center;'>{info['deleted']}</td>"
                    f"</tr>"
                )
            stats_table += "</table>"
            msg = f"Sync finished:<br>{stats_table}"

            showInfo(
                msg,
                title="Loading from Notion",
            )

        self.logger.info(f"Sync finished (auto sync:{self.is_auto_sync_flag}): {self.deck_update_info}")

    def handle_worker_error(self, error_message) -> None:
        """Handle worker error.

        :param error_message: error message
        """
        self._sync_errors.append(error_message)


class NoteExtractorSignals(QObject):
    """The signals available from a running extractor thread."""

    #: Extraction finished
    finished = pyqtSignal(str)
    #: Notes data
    result = pyqtSignal(str, object)
    #: Error
    error = pyqtSignal(str, str)


class NotesExtractorWorker(QRunnable):
    """Notes extractor worker thread."""

    def __init__(
        self,
        notion_token: str,
        page_id: str,
        recursive: bool,
        target_deck: str,
        notion_namespace: str,
        debug: bool = False,
    ):
        """Init notes extractor.

        :param notion_token: Notion token
        :param page_id: Notion page id
        :param recursive: recursive export
        :param notion_namespace: Notion namespace to form source links
        :param user_info: user info
        :param debug: debug log level
        """
        super().__init__()
        self.debug = debug
        self.logger = get_logger(f"worker_{page_id}", self.debug)
        self.signals = NoteExtractorSignals()
        self.notion_token = notion_token
        self.page_id = page_id
        self.recursive = recursive
        self.target_deck = target_deck
        self.notion_namespace = notion_namespace

    def run(self) -> None:
        """Extract note data from given Notion page.

        Export Notion page as HTML, extract notes data from the HTML and send
        results.
        """
        self.logger.info("Worker running")
        self.logger.info(f"Current page id: {self.page_id}. Current deck: {self.target_deck}")
        try:
            with TemporaryDirectory() as tmp_dir:
                # Export given Notion page as HTML
                tmp_path = safe_path(Path(tmp_dir))
                export_path = tmp_path / f"{self.page_id}.zip"
                self.logger.info("Exporting file: path=%s", str(export_path))
                client = NotionClient(self.notion_token, self.debug)
                client.export_page(
                    page_id=self.page_id,
                    destination=export_path,
                    recursive=self.recursive,
                )
                self.logger.info("Exported file downloaded: path=%s", str(export_path))
                # Extract notes data from the HTML files
                with zipfile.ZipFile(export_path) as zip_file:
                    zip_file.extractall(tmp_path)
                toggles = []
                for html_path in tmp_path.rglob("*.html"):
                    toggles += extract_notes_data(
                        source=Path(html_path),
                        notion_namespace=self.notion_namespace,
                        debug=self.debug,
                    )
                self.logger.info(f"Toggles extracted: '{self.target_deck}-{self.page_id}', count:{len(toggles)}")

        except NotionClientError as exc:
            self.logger.error("Error extracting toggles", exc_info=exc)
            error_msg = f"Cannot export {self.target_deck}-{self.page_id}:\n{exc}"
            self.signals.error.emit(f"{self.target_deck}-{self.page_id}", error_msg)
        except OSError as exc:  # Long path
            self.logger.warning("Error deleting files", exc_info=exc)
            # Delete manually
            rmtree(tmp_path, ignore_errors=True)
            self.signals.result.emit(f"{self.target_deck}-{self.page_id}", toggles)
        else:
            self.signals.result.emit(f"{self.target_deck}-{self.page_id}", toggles)
        finally:
            self.signals.finished.emit(f"{self.target_deck}-{self.page_id}")


NotionSyncPlugin()
