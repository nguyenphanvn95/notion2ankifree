"""Notion Sync plugin."""

import datetime
import json
import zipfile
from collections import defaultdict
from pathlib import Path
from shutil import rmtree
from tempfile import TemporaryDirectory
from traceback import format_exc
from typing import Any, Dict, List, Optional, Set, cast

from anki.collection import Collection
from aqt import mw
from aqt.utils import showCritical, showInfo
from jsonschema import ValidationError, validate
from PyQt6.QtCore import QObject, QRunnable, QThreadPool, QTimer, pyqtSignal
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QMenu, QMessageBox

from .anki_op_api import AnkiConnect
from .backend_auth import BackendServerError, UnvalidEmailOrPassword, User, UserInfo
from .deck_manager import DeckNotesManager
from .helpers import (
    BASE_DIR,
    enable_logging_to_file,
    get_logger,
    normalize_block_id,
    safe_path,
)
from .note_by_toggle import construct_anki_note_from_toggle
from .note_type_manager import MyNoteTypeManager
from .notion_client import NotionClient, NotionClientError
from .toggle_parser import (
    ToggleDetails,
    extract_notes_data,
)


FREE_TOGGLES_LIMIT = 30
SYNCINTERVAL = 8  # hours


class NotionSyncPlugin(QObject):
    """Notion sync plugin.

    Reads config, handles signals from Anki and spawns synchronization tasks
    on timer.
    """

    #: Default sync interval, min
    DEFAULT_SYNC_INTERVAL: int = 30

    def __init__(self):
        """Init plugin."""
        super().__init__()
        # While testing `mw` is None
        if not mw:
            return
        # Load config
        config = mw.addonManager.getConfig(__name__)
        mw.addonManager.setConfigUpdatedAction(__name__, self.reload_config)
        # Validate config
        self.config = self.get_valid_config(config)

        # Create a logger
        self.debug = "debug" in self.config and self.config["debug"]
        if self.debug:
            enable_logging_to_file()
        self.logger = get_logger(self.__class__.__name__, self.debug)
        self.logger.info("Config loaded: %s", self.config)

        # UserAPI  User info, 会在thread_get_user_info中初始化
        self.user_api: Optional[User] = None
        self.user_info: Optional[UserInfo] = None

        # 在加载完配置文件之后，获取用户信息
        # self.get_user_info()
        # 仅用来获取用户信息的线程池
        self.thread_get_user_info = QThreadPool()
        self._load_user_info()

        # Anki's collection and note manager
        self.collection: Optional[Collection] = None
        self._collection_seeded = False

        # The deck managers for each deck
        self.deck_managers: Optional[Dict[str, DeckNotesManager]] = None

        # create anki api
        self.anki_api: AnkiConnect

        # The note types manager
        self.note_type_manager: MyNoteTypeManager

        # Workers scaffolding
        self.thread_pool = QThreadPool()

        # The notes ids that were synced for each deck
        self.synced_note_ids: Dict[str, Set[int]] = defaultdict(set)
        self._alive_workers: int = 0
        self._sync_errors: List[str] = []
        # Sync stats
        self._processed = self._created = self._updated = self._deleted = 0
        # The notes ids that were already in the collection for each deck
        self.existing_note_ids: Dict[str, Set[int]] = defaultdict(set)
        self._remove_obsolete_on_sync = False
        # Add action to Anki menu
        self.notion_menu: Optional[QMenu] = None
        self.add_actions()

        # Add callback to seed the collection then it's ready
        # main_window_did_init.append(self.seed_collection)

        # Perform auto sync after main window initialization
        # main_window_did_init.append(self.auto_sync)

    def _validate_config(self, config: Optional[Dict[str, Any]]):
        """Validate config.

        :param config: config
        :raises ValidationError: if config is invalid
        """
        if not config:
            raise ValidationError("Config is empty")
        # Load schema and validate configuration
        with open(BASE_DIR / "schemas/config_schema.json", encoding="utf8") as s:
            schema = json.load(s)
        validate(config, schema)

    def get_valid_config(self, config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Get valid configuration. 在最开始的时候，加载配置文件。

        :param config: configuration
        :returns: either configuration provided (if it's valid) or default
            config
        """
        try:
            self._validate_config(config)
        except ValidationError as exc:
            showCritical(str(exc), title="Notion loader config load error")
            assert mw  # mypy
            default_config = mw.addonManager.addonConfigDefaults(str(BASE_DIR))
            return cast(Dict[str, Any], default_config)
        else:
            assert config  # mypy
            return config

    def reload_config(self, new_config: Optional[Dict[str, Any]]) -> None:
        """Reload configuration.

        :param new_config: new configuration
        """
        if not new_config:
            assert mw  # mypy
            new_config = mw.addonManager.getConfig(__name__)
        try:
            self._validate_config(new_config)
        except ValidationError as exc:
            self.logger.error("Config update error", exc_info=exc)
            showCritical(str(exc), title="Notion loader config update error")
        else:
            assert new_config  # mypy
            self.config = new_config

            # 在加载完配置文件之后，获取用户信息
            self._load_user_info()

    def add_actions(self):
        """Add Notion menu entry with actions to Tools menu."""
        assert mw  # mypy
        self.notion_menu = mw.form.menuTools.addMenu("NotionSync")
        incremental_sync_action = QAction("Incremental Sync", mw)
        absolute_sync_action = QAction("Absolute Sync", mw)
        about_action = QAction("About", mw)

        incremental_sync_action.triggered.connect(self.sync)
        absolute_sync_action.triggered.connect(self.sync_and_remove_obsolete)
        about_action.triggered.connect(self.show_about_dialog)

        self.notion_menu.addActions((incremental_sync_action, absolute_sync_action, about_action))

    def show_about_dialog(self):
        message = f"""
            <p style="font-size: 14pt;">
                <b>NotionSync</b>
            </p>
            <p style="font-size: 10pt;">
                当前用户: {self.user_info.username if self.user_info else "未登录"}
            <p style="font-size: 12pt;">
            <p style="font-size: 10pt;">
                Version v1.0.1
            <p style="font-size: 12pt;">
                主要功能:
            </p>
            <ol style="font-size: 11pt;">
                <li>增量同步: 将Notion中的数据同步到Anki中, 不会删除Anki中存在而Notion中不存在笔记</li>
                <li>绝对同步: 保持Anki与Notion的数据绝对一致, 对于Anki中存在而Notion中不存在的笔记, 将会删除</li>
            </ol>
            <p style="font-size: 10pt;">
                更多介绍, 请访问 <a href="www.notion2anki.com">notion2anki</a>
            </p>
            <p style="font-size: 10pt;">
                如有任何疑问, 请发送邮件至 notion2anki@outlook.com
            </p>
            """
        QMessageBox.about(mw, "About", message)
        # QMessageBox.about(mw, "About NotionSync", "Version v1.0.1")

    def _load_collection(self):
        """Load collection."""
        assert mw
        self.collection = mw.col
        if not self.collection:
            self.logger.error("Collection is empty")
            return

    def _load_user_info(self):
        """在初始化 和 重新加载配置文件之后，加载用户信息."""
        self.user_api = User(self.config["user_email"], self.config["user_password"], debug=self.debug)
        work = GetUserInfoWorker(self.user_api, debug=self.debug)
        work.signals.result.connect(self.handle_user_info_result)
        work.signals.error.connect(self.handle_user_info_error)
        work.signals.finished.connect(self.handle_user_info_finished)
        # Start worker
        self.thread_get_user_info.start(work)

    def seed_collection(self):
        """collection 初始化; 模板创建, deck manager初始化. anki_api 初始化."""
        self._load_collection()
        if not self.collection:
            return

        # create anki api
        self.anki_api = AnkiConnect(collection=self.collection, window=mw)

        # The note types manager
        self.note_type_manager = MyNoteTypeManager(anki_api=self.anki_api, debug=self.debug)
        try:
            self.note_type_manager.create_model(reset_note_type=False)
            self.logger.info("All Note type created")
        except Exception as e:
            self.logger.error("Error creating note type", exc_info=e)
            showCritical(str(e), title="note type creation error")
            return

        # Create notes managers
        self.logger.info("Creating deck managers...")
        self.deck_managers = {}
        for page_conf in self.get_notion_pages_config():
            page_id, target_deck, _ = page_conf

            self.logger.info(f"Creating deck manager for Notion page:{page_id} and deck:{target_deck}")

            self.deck_managers[target_deck] = DeckNotesManager(
                deck_name=target_deck,
                anki_api=self.anki_api,
                debug=self.debug,
            )
        self.logger.info("Deck managers created")

        self.logger.info("Collection initialized")
        self.existing_note_ids = {deck_name: dm.existing_note_ids for deck_name, dm in self.deck_managers.items()}
        self._collection_seeded = True

    def handle_user_info_result(self, user_info: UserInfo) -> None:
        """Handle user info result.

        :param user_info: user info
        """
        self.user_info = user_info
        self.logger.info(f"User info loaded: {user_info}")

    def handle_user_info_error(self, error_message: str) -> None:
        """Handle user info error. if error, show error message and set user_info to None.

        :param error_message: error message
        """
        self.user_info = None
        self.logger.error(f"Error loading user info: {error_message}")
        showCritical(error_message, title="Notion2Anki Login Error")

    def handle_user_info_finished(self, email: str) -> None:
        """Handle user info finished."""
        self.logger.info("User info loading finished")
        # If user is redeemed, start auto sync
        if self.user_info and self.user_info.redeemed:
            self.logger.info("User is redeemed, start auto sync")
            # Create and run timer
            self._is_auto_sync = True
            self.timer = QTimer()
            sync_interval_milliseconds = (
                self.config.get("sync_every_minutes", self.DEFAULT_SYNC_INTERVAL)
                * 60  # seconds
                * 1000  # milliseconds
            )
            if sync_interval_milliseconds:
                self.timer.setInterval(sync_interval_milliseconds)
                self.timer.timeout.connect(self.auto_sync)
                self.timer.start()
        else:
            self.logger.info("User is not redeemed, don't start auto sync")

    def handle_worker_result(self, deck_name: str, toggles: List[ToggleDetails]) -> None:
        """Add notes to collection.

        :param deck_name: 卡组名称
        :param toggles: List[ToggleDetails] 从 Notion 中提取的toggle
        """
        assert self.deck_managers and deck_name in self.deck_managers
        try:
            for toggle in toggles:
                note_by_toggle = construct_anki_note_from_toggle(toggle)
                self._processed += 1
                # 获取 该 note 对应的 note type, 即 模板类型
                model_name = self.note_type_manager.note_by_toggle_map_note_type_name(note_by_toggle)
                # 根据 note正面内容在 该卡组里面查找是否存在该 正面内容对应的 note
                note_id = self.deck_managers[deck_name].find_note_by_front(note_by_toggle.Front)
                if note_id:
                    try:
                        self.deck_managers[deck_name].update_exist_anki_note(
                            ankinote_id=note_id,
                            note_by_toggle=note_by_toggle,
                            model_name=model_name,
                        )
                        self._updated += 1
                    except Exception as e:
                        # 更新失败, 删除该 note, 重新创建
                        self.logger.error(
                            f"Error updating note: {note_id}, {note_by_toggle.Front}",
                            exc_info=e,
                        )

                        # 删除该 note，重新创建
                        self.deck_managers[deck_name].remove_notes([note_id])
                        try:
                            note_id = self.deck_managers[deck_name].create_new_anki_note(
                                note_by_toggle=note_by_toggle, model_name=model_name
                            )
                            self._created += 1
                        except Exception as e:
                            self.logger.error(
                                f"Error creating note: {note_by_toggle.Front}",
                                exc_info=e,
                            )
                # Create new note
                else:
                    try:
                        note_id = self.deck_managers[deck_name].create_new_anki_note(
                            note_by_toggle=note_by_toggle, model_name=model_name
                        )
                        self._created += 1
                    except Exception as e:
                        self.logger.error(
                            f"Error creating note: {note_by_toggle.Front}",
                            exc_info=e,
                        )

                self.synced_note_ids[deck_name].add(note_id)
        except Exception:
            error_msg = format_exc()
            self._sync_errors.append(error_msg)

    def handle_sync_finished(self, deck: str) -> None:
        """Handle sync finished.

        In case of any error - show error message in manual mode and do nothing
        otherwise.  If no error - save the collection and show sync statistics
        in manual mode.  If `self._remove_obsolete_on_sync` is True - remove
        all notes that is not added or updated in current sync.

        :param deck: deck name that finished sync (Only this deck is finished)
        """
        assert self.deck_managers

        assert self.collection  # mypy
        self.logger.info(f"Worker finished: {deck}")
        self._alive_workers -= 1
        # If all workers finished, execute following code in this function, otherwise wait
        if self._alive_workers:
            return
        assert self.notion_menu  # mypy
        self.notion_menu.setTitle("NotionSync")
        # Show errors if manual sync
        if self._sync_errors:
            error_msg = "\n".join(self._sync_errors)
            if not self._is_auto_sync:
                showCritical(error_msg, title="Loading from Notion failed")
            else:
                showCritical(error_msg, title="Loading from Notion failed")
        # If no errors - save collection and refresh Anki window
        else:
            if self._remove_obsolete_on_sync:
                # Get the note id that should be removed per deck
                ids_to_remove = defaultdict(set)
                temp_total_removed = 0
                for deck in self.existing_note_ids.keys():
                    temp_ids = self.existing_note_ids[deck] - self.synced_note_ids[deck]
                    if len(temp_ids) > 0:
                        ids_to_remove[deck] = temp_ids
                        self.logger.info(f"Will delete {len(temp_ids)} note(s) in {deck}")
                        temp_total_removed += len(ids_to_remove)
                if ids_to_remove:
                    msg = f"Will delete {temp_total_removed} obsolete note(s), " f"continue?"
                    assert mw  # mypyc
                    do_delete = QMessageBox.question(
                        mw,
                        "Confirm deletion",
                        msg,
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    )
                    if do_delete == QMessageBox.StandardButton.Yes.value:
                        for deck, notes_id in ids_to_remove.items():
                            self.deck_managers[deck].remove_notes(list(notes_id))
                        self._deleted += len(notes_id)

            self.collection.save(trx=False)
            mw.maybeReset()  # type: ignore[union-attr]
            mw.deckBrowser.refresh()  # type: ignore[union-attr]
            stats = (
                f"Processed: {self._processed}\n"
                f"Created: {self._created}\n"
                f"Updated: {self._updated}\n"
                f"Deleted: {self._deleted}"
            )
            if not self._is_auto_sync:
                showInfo(
                    f"Successfully loaded:\n{stats}",
                    title="Loading from Notion",
                )
        self.logger.info(
            "Sync finished, processed=%s, created=%s, updated=%s, deleted=%s",
            self._processed,
            self._created,
            self._updated,
            self._deleted,
        )
        self._reset_stats()

    def handle_worker_error(self, error_message) -> None:
        """Handle worker error.

        :param error_message: error message
        """
        self._sync_errors.append(error_message)

    def auto_sync(self) -> None:
        """Perform synchronization in background."""
        self.logger.info("Auto sync started")
        # Reload config
        assert mw  # mypy
        self.reload_config(None)
        self._is_auto_sync = True
        self._sync()

    def is_allowed_to_sync(self) -> bool:
        if self.user_info and self.user_info.redeemed:
            return True, ""

        # 获取上一次同步的时间
        self.last_conversion_record = self.user_api.get_conversion_record().get("last_conversion", None)
        if self.last_conversion_record:
            last_sync_time = self.last_conversion_record.get("conversion_time", None)
            if last_sync_time:
                # 使用国际标准时间
                if datetime.datetime.utcnow() - datetime.datetime.strptime(
                    last_sync_time, "%Y-%m-%d %H:%M:%S"
                ) < datetime.timedelta(hours=SYNCINTERVAL):
                    # 转为当地时区时间
                    locl_time = datetime.datetime.strptime(last_sync_time, "%Y-%m-%d %H:%M:%S").astimezone()
                    return False, f"Sync interval is not reached, last sync time:{locl_time}"

        return True, ""

    def sync(self) -> None:
        """Perform synchronization and report result."""
        self.logger.info("Sync started")
        # Reload config
        assert mw  # mypy
        self.reload_config(None)  # 每次同步都重新加载配置文件
        if not self._alive_workers:
            is_allowed, reason = self.is_allowed_to_sync()
            if not is_allowed:
                showCritical(reason, title="Notion2Anki")
                return
            self._is_auto_sync = False
            self._sync()
        else:
            showInfo(
                "Sync is already in progress, please wait",
                title="Load from Notion",
            )

    def sync_and_remove_obsolete(self) -> None:
        """Perform synchronization and remove obsolete notes."""
        self.logger.info("Sync with remove obsolete started")
        self._remove_obsolete_on_sync = True
        self.sync()

    def _reset_stats(self) -> None:
        """Reset variables before sync.

        Saves pre-sync existing note ids and resets sync stats and errors.
        """
        self._remove_obsolete_on_sync = False
        self.synced_note_ids = defaultdict(set)
        assert self.deck_managers
        self.existing_note_ids = {deck: dm.existing_note_ids for deck, dm in self.deck_managers.items()}
        self._processed = self._created = self._updated = self._deleted = 0
        self._sync_errors = []

    def _sync(self) -> None:
        """Start sync."""
        self.logger.warning("Collection trying to seed now")
        self.seed_collection()  # 每次同步都重新初始化 collection
        if not self._collection_seeded:
            return
        assert self.notion_menu  # mypy
        self.notion_menu.setTitle("Notion (syncing...)")
        for page_conf in self.get_notion_pages_config():
            page_id, target_deck, recursive = page_conf
            self.logger.info(f"Starting worker for page: {page_id} in {target_deck}")
            worker = NotesExtractorWorker(
                notion_token=self.config["notion_token"],
                page_id=page_id,
                recursive=recursive,
                target_deck=target_deck,
                notion_namespace=self.config.get("notion_namespace", ""),
                user_info=self.user_info,
                debug=self.debug,
            )
            worker.signals.result.connect(self.handle_worker_result)
            worker.signals.error.connect(self.handle_worker_error)
            worker.signals.finished.connect(self.handle_sync_finished)
            # Start worker
            self.thread_pool.start(worker)
            self._alive_workers += 1

    def get_notion_pages_config(self) -> List[List[str]]:
        """Get Notion pages configuration. For page_spec without a specified target_deck value, the target_deck will default to using the page_id.

        :returns: Notion pages configuration, including page_id, target_deck and recursive flag
        """
        pages_conf = []
        for page_spec in self.config.get("notion_pages", []):
            ori_page_id = page_spec["page_id"]
            page_id = normalize_block_id(ori_page_id)
            target_deck = page_spec.get("target_deck", None)
            if "::" in target_deck:
                if self.user_info is None or self.user_info.redeemed is False:
                    self.logger.error(f"User is not redeemed, cannot sync deck: {target_deck}")
                    continue
            recursive = page_spec.get("recursive", False)
            if target_deck == "" or target_deck is None:
                target_deck = ori_page_id

            pages_conf.append([page_id, target_deck, recursive])

        return pages_conf


class UserInfoSignals(QObject):
    """The signals available from a running user info thread."""

    # Extraction finished
    finished = pyqtSignal(str)
    #: User info data
    result = pyqtSignal(object)
    #: Error
    error = pyqtSignal(str)


class NoteExtractorSignals(QObject):
    """The signals available from a running extractor thread."""

    #: Extraction finished
    finished = pyqtSignal(str)
    #: Notes data
    result = pyqtSignal(str, object)
    #: Error
    error = pyqtSignal(str)


class GetUserInfoWorker(QRunnable):
    """Get user info worker thread."""

    def __init__(self, user_api: User, debug: bool = False):
        """Init user info worker."""
        super().__init__()
        self.debug = debug
        self.logger = get_logger(f"worker_get_user:{user_api}", self.debug)
        self.signals = UserInfoSignals()
        self.user_api = user_api

    def run(self) -> None:
        """get user info."""
        self.logger.info("Worker started")
        try:
            user_info = self.user_api.get_user()
        except BackendServerError as e:
            self.logger.error("Error loading user info", exc_info=e)
            self.signals.error.emit(f"Notion2Anki server error:{e}")
        except UnvalidEmailOrPassword as e:
            self.logger.error("Error loading user info", exc_info=e)
            self.signals.error.emit("Invalid email or password")
        except Exception as e:
            self.logger.error("Error loading user info", exc_info=e)
            self.signals.error.emit(str(e))
        else:
            self.signals.result.emit(user_info)
        finally:
            self.signals.finished.emit(self.user_api.email)


class NotesExtractorWorker(QRunnable):
    """Notes extractor worker thread."""

    def __init__(
        self,
        notion_token: str,
        page_id: str,
        recursive: bool,
        target_deck: str,
        notion_namespace: str,
        user_info: UserInfo,
        debug: bool = False,
    ):
        """Init notes extractor.

        :param notion_token: Notion token
        :param page_id: Notion page id
        :param recursive: recursive export
        :param notion_namespace: Notion namespace to form source links
        :param user_info: user info
        :param debug: debug log level
        """
        super().__init__()
        self.debug = debug
        self.logger = get_logger(f"worker_{page_id}", self.debug)
        self.signals = NoteExtractorSignals()
        self.notion_token = notion_token
        self.page_id = page_id
        self.recursive = recursive
        self.target_deck = target_deck
        self.notion_namespace = notion_namespace
        self.user_info = user_info

    def run(self) -> None:
        """Extract note data from given Notion page.

        Export Notion page as HTML, extract notes data from the HTML and send
        results.
        """
        self.logger.info("Worker started")
        self.logger.info(f"Current page id: {self.page_id}. Current deck: {self.target_deck}")
        try:
            with TemporaryDirectory() as tmp_dir:
                # Export given Notion page as HTML
                tmp_path = safe_path(Path(tmp_dir))
                export_path = tmp_path / f"{self.page_id}.zip"
                self.logger.info("Exporting file: path=%s", str(export_path))
                client = NotionClient(self.notion_token, self.debug)
                client.export_page(
                    page_id=self.page_id,
                    destination=export_path,
                    recursive=self.recursive,
                )
                self.logger.info("Exported file downloaded: path=%s", str(export_path))
                # Extract notes data from the HTML files
                with zipfile.ZipFile(export_path) as zip_file:
                    zip_file.extractall(tmp_path)
                toggles = []
                for html_path in tmp_path.rglob("*.html"):
                    toggles += extract_notes_data(
                        source=Path(html_path),
                        notion_namespace=self.notion_namespace,
                        debug=self.debug,
                    )
                # 对于未登录用户或者未兑换的用户，只提取前 FREE_TOGGLES_LIMIT 个toggle
                if self.user_info is None or self.user_info.redeemed is False:
                    self.logger.info("User is not redeemed or not logged in, so not all toggles will be extracted")
                    toggles = toggles[:FREE_TOGGLES_LIMIT]

                self.logger.info(f"Toggles extracted: deck:{self.target_deck}, count:{len(toggles)}")
        except NotionClientError as exc:
            self.logger.error("Error extracting toggles", exc_info=exc)
            error_msg = f"Cannot export {self.page_id}:\n{exc}"
            self.signals.error.emit(error_msg)
        except OSError as exc:  # Long path
            self.logger.warning("Error deleting files", exc_info=exc)
            # Delete manually
            rmtree(tmp_path, ignore_errors=True)
        else:
            self.signals.result.emit(self.target_deck, toggles)
        finally:
            self.signals.finished.emit(self.target_deck)


NotionSyncPlugin()
