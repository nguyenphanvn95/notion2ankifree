from PyQt6.QtCore import QEvent, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QPainter, QPen
from PyQt6.QtWidgets import QGraphicsOpacityEffect, QWidget

from .animation import Animation, AnimationHandler


class ToggleSwitch(QWidget):
    defaultStyles = ("win10", "ios", "android")

    toggled = pyqtSignal(bool)

    def __init__(self, text="", style="win10", on=False):
        super().__init__()

        self.text = text

        self.on = on

        # TODO: find a better way for opacity
        self.opacity = QGraphicsOpacityEffect(self)
        self.opacity.setOpacity(1)
        self.setGraphicsEffect(self.opacity)

        if style not in ToggleSwitch.defaultStyles:
            raise Exception(f"'{style}' is not a default style.")
        self.style = style

        if self.style == "win10":
            # onColoor为: #4CAF50
            self.onColor = QColor(33, 150, 243)
            self.offColor = QColor(0, 0, 0)

            self.handleAlpha = True
            self.handleColor = QColor(255, 255, 255)

            self.width = 26
            self.radius = 21

        elif self.style == "ios":
            self.onColor = QColor(73, 208, 96)
            self.offColor = QColor(250, 250, 250)

            self.handleAlpha = False
            self.handleColor = QColor(255, 255, 255)

            self.width = 21
            self.radius = 29

        elif self.style == "android":
            self.onColor = QColor(0, 150, 136)
            self.offColor = QColor(255, 255, 255)

            self.handleAlpha = True
            self.handleColor = QColor(255, 255, 255)

            self.width = 35
            self.radius = 26

        self.setMinimumSize(self.width + (self.radius * 2) + (len(self.text) * 10), self.radius + 2)

        self.anim = AnimationHandler(self, 0, self.width, Animation.easeOutCirc)
        if self.on:
            self.anim.value = 1

    def __repr__(self):
        return f"<pyqt6Custom.ToggleSwitch(isToggled={self.isToggled()})>"

    def isToggled(self):
        return self.on

    def setToggle(self, toggle):
        if self.on and toggle:
            return
        if not self.on and not toggle:
            return
        if self.on and not toggle:
            self.on = False
            self.anim.start(reverse=True)
        elif not self.on and toggle:
            self.on = True
            self.anim.start()
        self.update()

    def desaturate(self, color):
        cc = getattr(self, color)
        h = cc.hue()
        if h < 0:
            h = 0
        s = cc.saturation() // 4
        if s > 255:
            s = 255
        c = QColor.fromHsv(h, s, cc.value())
        setattr(self, color, c)

    def saturate(self, color):
        cc = getattr(self, color)
        h = cc.hue()
        if h < 0:
            h = 0
        s = cc.saturation() * 4
        if s > 255:
            s = 255
        c = QColor.fromHsv(h, s, cc.value())
        setattr(self, color, c)

    def update(self, *args, **kwargs):
        self.anim.update()
        super().update(*args, **kwargs)

    def mousePressEvent(self, event):
        if self.isEnabled():
            if self.on:
                self.on = False
                self.anim.start(reverse=True)
            else:
                self.on = True
                self.anim.start()
            self.update()

            self.toggled.emit(self.on)

    def changeEvent(self, event):
        if event.type() == QEvent.Type.EnabledChange:
            if self.isEnabled():
                self.saturate("onColor")
                self.saturate("offColor")
                self.saturate("handleColor")
                self.opacity.setOpacity(1.00)
            else:
                self.desaturate("onColor")
                self.desaturate("offColor")
                self.desaturate("handleColor")
                self.opacity.setOpacity(0.4)

            self.update()

        else:
            super().changeEvent(event)

    def paintEvent(self, event):
        pt = QPainter()
        pt.begin(self)
        pt.setRenderHint(QPainter.RenderHint.Antialiasing)

        if self.style == "win10":
            if self.on:
                # pen = QPen(self.onColor, 1, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
                pen = QPen(
                    self.onColor,
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)
                brush = QBrush(self.onColor)
                pt.setBrush(brush)

                r = self.radius
                w = self.width

                pt.drawChord(r, 1, r, r, 90 * 16, 180 * 16)
                pt.drawChord(r + w, 1, r, r, -90 * 16, 180 * 16)
                pt.drawRect(r + r // 2, 1, w, r)

                if self.handleAlpha:
                    pt.setBrush(pt.background())
                else:
                    pt.setBrush(QBrush(self.handleColor))
                offset = r * 0.4
                pt.drawEllipse(
                    int(r + offset / 2 + self.anim.current()),
                    int(1 + offset / 2),
                    int(r - offset),
                    int(r - offset),
                )

            else:
                # pen = QPen(self.offColor, 1, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
                pen = QPen(
                    self.offColor,
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)

                r = self.radius
                w = self.width

                pt.drawArc(r, 1, r, r, 90 * 16, 180 * 16)
                pt.drawArc(r + w, 1, r, r, -90 * 16, 180 * 16)
                pt.drawLine(r + r // 2, 1, r + w + r // 2, 1)
                pt.drawLine(r + r // 2, r + 1, r + w + r // 2, r + 1)

                brush = QBrush(self.offColor)
                pt.setBrush(brush)
                offset = r * 0.4
                pt.drawEllipse(
                    int(r + offset / 2 + self.anim.current()),
                    int(offset / 2 + 1),
                    int(r - offset),
                    int(r - offset),
                )

        elif self.style == "ios":
            if self.on:
                # pen = QPen(self.onColor, 1, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
                pen = QPen(
                    self.onColor,
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)
                brush = QBrush(self.onColor)
                pt.setBrush(brush)

                r = self.radius
                w = self.width

                pt.drawChord(r, 1, r, r, 90 * 16, 180 * 16)
                pt.drawChord(r + w, 1, r, r, -90 * 16, 180 * 16)
                pt.drawRect(r + r // 2, 1, w, r)

                if self.handleAlpha:
                    pt.setBrush(pt.background())
                else:
                    pt.setBrush(QBrush(self.handleColor))
                offset = r * 0.025
                pt.drawEllipse(
                    int(r + offset / 2 + self.anim.current()),
                    int(1 + offset / 2),
                    int(r - offset),
                    int(r - offset),
                )

            else:
                pen = QPen(
                    self.offColor.darker(135),
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)
                brush = QBrush(self.offColor)
                pt.setBrush(brush)

                r = self.radius
                w = self.width

                pt.drawChord(r, 1, r, r, 90 * 16, 180 * 16)
                pt.drawChord(r + w, 1, r, r, -90 * 16, 180 * 16)
                pt.drawRect(r + r // 2, 1, w, r)
                pt.setPen(QPen(self.offColor))
                pt.drawRect(r + r // 2 - 2, 2, w + 4, r - 2)

                if self.handleAlpha:
                    pt.setBrush(pt.background())
                else:
                    pt.setBrush(QBrush(self.handleColor))
                pt.setPen(QPen(self.handleColor.darker(160)))
                offset = r * 0.025
                pt.drawEllipse(
                    int(r + offset / 2 + self.anim.current()),
                    int(1 + offset / 2),
                    int(r - offset),
                    int(r - offset),
                )

        elif self.style == "android":
            if self.on:
                pen = QPen(
                    self.onColor.lighter(145),
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)
                brush = QBrush(self.onColor.lighter(145))
                pt.setBrush(brush)

                r = self.radius
                w = self.width

                pt.drawChord(r + r // 4, 1 + r // 4, r // 2, r // 2, 90 * 16, 180 * 16)
                pt.drawChord(r + w + r // 4, 1 + r // 4, r // 2, r // 2, -90 * 16, 180 * 16)
                pt.drawRect(r + r // 2, 1 + r // 4, w, r // 2)

                pt.setBrush(QBrush(self.onColor))
                pt.setPen(QPen(self.onColor))
                pt.drawEllipse(int(r + self.anim.current()), 1, int(r), int(r))

            else:
                pen = QPen(
                    self.offColor.darker(130),
                    1,
                    Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap,
                    Qt.PenJoinStyle.RoundJoin,
                )
                pt.setPen(pen)
                brush = QBrush(self.offColor.darker(130))
                pt.setBrush(brush)

                r = self.radius
                w = self.width

                pt.drawChord(r + r // 4, 1 + r // 4, r // 2, r // 2, 90 * 16, 180 * 16)
                pt.drawChord(r + w + r // 4, 1 + r // 4, r // 2, r // 2, -90 * 16, 180 * 16)
                pt.drawRect(r + r // 2, 1 + r // 4, w, r // 2)

                pt.setBrush(QBrush(self.offColor))
                pt.setPen(QPen(self.offColor.darker(140)))
                pt.drawEllipse(int(r + self.anim.current()), 1, int(r), int(r))

        font = pt.font()
        pt.setFont(font)
        # pt.setPen(QPen(Qt.black))
        pt.setPen(QPen(Qt.GlobalColor.black))

        if len(self.text) > 0:
            pt.drawText(int(w + r * 2 + 10), int(r // 2 + r // 4), self.text)

        pt.end()

        if not self.anim.done():
            self.update()

    def disable(self, msg=""):
        """Disable the switch, making it unclickable. 且鼠标点击时会显示msg"""
        if self.on:
            self.on = False
            self.anim.start(reverse=True)
            self.anim.update()

        self.setEnabled(False)
        if msg:
            self.setToolTip(msg)

    def enable(self):
        self.setEnabled(True)
        self.setToolTip("")
