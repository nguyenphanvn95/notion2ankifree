from typing import Optional, Set

from anki.notes import Note
from bs4 import BeautifulSoup

from .anki_op_api import AnkiConnect
from .helpers import get_logger, safe_str
from .note_by_toggle import BaseAnkiNote, ClozeAnkiNote, StdAnkiNote


class DeckNotesManager:
    """管理某一个deck的所有notes, 包括创建notes, 更新notes, 删除notes等操作."""

    def __init__(self, deck_name, anki_api: AnkiConnect, debug: bool = False):
        self.deck_name = deck_name

        self.anki_api = anki_api
        self.logger = get_logger(self.__class__.__name__, debug)

        self.deck_id = self.get_deck()

    def get_deck(self) -> int:
        """Get or create target deck.

        :returns: working deck id
        """
        deck_id = self.anki_api.collection.decks.id(self.deck_name, create=True)
        assert deck_id  # mypy
        return deck_id

    @property
    def existing_note_ids(self) -> Set[int]:
        """Existing note ids in the deck.

        :returns: existing note ids
        """
        return self.anki_api.getNotesIdInDeck(self.deck_name)

    def _escape_query(self, query: str) -> str:
        """Escape special characters in string for use in a query.

        :param query: query
        :returns: escaped query
        """
        escaped_query = query.replace("\\", "\\\\").replace('"', '\\"')
        return escaped_query

    def find_note_by_front(self, note_front: str) -> Optional[int]:
        """Find note by its front side in the self.deck.

        :param note: note
        :returns: note id if found else None
        """
        front = self._escape_query(note_front)
        query = f'deck:"{self.deck_name}" front:"{front}"'
        self.logger.debug("Searching with a query: %s", query)
        note_ids = self.anki_api.findNotesByQuery(query)
        self.logger.debug("Result: %s", note_ids)
        return note_ids[0] if (note_ids and len(note_ids) > 0) else None

    def remove_notes(self, note_ids: Set[int]) -> None:
        """Remove notes with given IDs.

        :param note_ids: note ids to remove
        """
        self.logger.info("Removing notes: %s", note_ids)
        self.anki_api.deleteNotes(note_ids)

    def add_anki_note_to_anki(self, anki_note: Note) -> int:
        """将 note 添加到 deck 中."""
        deck_id = self.deck_id
        # 在执行完这一步之后，anki_note才有id属性，之前id为0
        # TODO: nCardsAdded 不能和 int 类型比较
        nCardsAdded = self.anki_api.collection.add_note(anki_note, deck_id)
        if nCardsAdded.note is False or nCardsAdded.card is False:
            raise Exception("The field values you have provided would make an empty question on all cards.")
        return anki_note.id

    @staticmethod
    def format_audio_video_tag(html_content):
        """将notion中音视频所在的figure标签转为普通div标签, 即 用 audio + figcaption 替换 figure 标签
        <figure>
            <div class="source">
                <a href="xxxx.mpga">
                    <audio controls src="xxxx.mpga">
                    </audio>
                </a>
                <figcaption>
                    这是第一个音频素材
                </figcaption>
        </figure>

        to

        <div>
            <audio controls="" src="xxxx.mpga">
            </audio>
            <figcaption>
                这是第一个音频素材
            </figcaption>
        </div>
        """
        # 使用 BeautifulSoup 解析 HTML
        soup = BeautifulSoup(html_content, "html.parser")

        # 查找所有的 <audio> 标签 和 <video> 标签
        audio_tags = soup.find_all("audio") + soup.find_all("video")

        # 遍历每个 <audio>和 <video> 标签
        for audio_tag in audio_tags:
            # 找到父标签 <a>，如果存在
            parent_a = audio_tag.parent
            if parent_a and parent_a.name == "a":
                # 找到父标签的父标签 <figure>
                parent_div = parent_a.parent
                # 判断 parent_div 是否为 div 标签 且 class 属性是否为 'source'
                if parent_div and parent_div.name == "div" and parent_div["class"][0] == "source":
                    parent_figure = parent_div.parent
                    # 判断 parent_figure 是否为 figure 标签
                    if parent_figure and parent_figure.name == "figure":
                        # 到这里基本确定 audio_tag 是要找的标签, 可以进行后续操作

                        # 找到 figcaption 标签, 可能是不存在的，需要判断
                        figcaption_tag = parent_div.find("figcaption")
                        # 将 audio 标签 和 figcaption_tag 构造一个新的 div 标签，然后把 parent_figure 替换为这个新的 div 标签
                        new_div = soup.new_tag("div")
                        # 设置 该div style="text-align: center; max-width: 100%;"
                        new_div["style"] = "text-align: center; max-width: 100%;"
                        new_div.append(audio_tag)
                        if figcaption_tag:
                            new_div.append(figcaption_tag)
                        parent_figure.replace_with(new_div)

        # 查找所有的 <img> 标签
        img_tags = soup.find_all("img")

        # 遍历每个 img 标签
        for img_tag in img_tags:
            # 找到父标签 <a>，如果存在 且有 href 属性
            parent_a = img_tag.parent
            if parent_a and parent_a.name == "a":
                parent_figure = parent_a.parent
                if parent_figure and parent_figure.name == "figure":
                    # 到这里基本确定 img_tag 是要找的标签, 可以进行后续操作
                    print("0k")
                    # 找到 figcaption 标签, 可能是不存在的，需要判断
                    figcaption_tag = parent_figure.find("figcaption")
                    # 将 img 标签 和 figcaption_tag 构造一个新的 div 标签，然后把 parent_figure 替换为这个新的 div 标签
                    new_div = soup.new_tag("div")
                    # 设置 该div style="text-align: center; max-width: 100%;"
                    new_div["style"] = "text-align: center;"
                    new_div.append(img_tag)
                    if figcaption_tag:
                        new_div.append(figcaption_tag)
                    parent_figure.replace_with(new_div)
        # 返回处理后的 HTML 字符串 且不包含\n \t等字符
        return str(soup).replace("\n", "").replace("\t", "")

    def _update_media_info(self, note_by_toggle: BaseAnkiNote) -> BaseAnkiNote:
        """准备创建 anki note 需要的信息, 主要是把 note_by_toggle 中的 media 上传到 anki 中.然后返回更改其中的媒体信息等

        :param note: note:BaseAnkiNote
        :param model_name: Anki model(note type) name
        :param deck_name: Anki deck name
        """
        anki_api = self.anki_api

        # Add media to Anki, 同时, 更新 note.back 中的 media url
        if note_by_toggle.Medias:
            for media in note_by_toggle.Medias:
                if not anki_api.hasMediaFile(media.filename):
                    maybe_new_filename = anki_api.media().write_data(media.filename, media.data)
                else:
                    maybe_new_filename = media.filename

                if media.filename != maybe_new_filename:
                    if isinstance(note_by_toggle, ClozeAnkiNote):
                        note_by_toggle.Extra = note_by_toggle.Extra.replace(media.filename, maybe_new_filename)
                    else:
                        note_by_toggle.Back = note_by_toggle.Back.replace(media.filename, maybe_new_filename)

                # 对于音频文件，需要在 note 中添加相应的字段
                if media.media_type == 1:
                    audio_element = f"""
                        <audio controls src="{maybe_new_filename}" style="width: 60vw; max-width: 100%;">
                        </audio>"""
                    if isinstance(note_by_toggle, ClozeAnkiNote):
                        note_by_toggle.Extra = note_by_toggle.Extra.replace(
                            media.url,
                            audio_element,
                        )
                    else:
                        # anki中常规的音频文件的插入方式, 无进度条之类的
                        # note_by_toggle.Back = note_by_toggle.Back.replace(
                        #     media.url, f"[sound:{maybe_new_filename}]"
                        # )
                        # 有进度条
                        note_by_toggle.Back = note_by_toggle.Back.replace(
                            media.url,
                            audio_element,
                        )
                # 对于视频文件，需要在 note 中添加相应的字段
                elif media.media_type == 2:
                    # 根据 maybe_new_filename 推断视频文件的类型
                    video_type = maybe_new_filename.split(".")[-1]
                    # following by https://forums.ankiweb.net/t/how-to-create-card-with-video-without-opening-that-video-separately/11350/4
                    video_element = f"""
                        <video controls id="videoPlayer" style="width: 80vw; max-width: 100%;">
                            <source src="{maybe_new_filename}" type="video/{video_type}">
                                <p>
                                    Your browser doesn't support HTML video. Here is a
                                        <a href="myVideo.mp4" download="{media.url}">
                                            link to the video
                                        </a>
                                        instead.
                                </p>
                        </video>"""

                    if isinstance(note_by_toggle, ClozeAnkiNote):
                        note_by_toggle.Extra = note_by_toggle.Extra.replace(
                            media.url,
                            video_element,
                        )
                    else:
                        note_by_toggle.Back = note_by_toggle.Back.replace(
                            media.url,
                            video_element,
                        )

                        # <video id="myvid1" src="myvideo.mp4" controlsList="nodownload" controls></video>
                        # note_by_toggle.Back += """<video controls controlsList="nodownload" id="videoPlayer" style="max-width: 100%;"><source src="AnkiFlashCard203a77f1a2c4d349bfb7bb262efdf298d1coverrfriendswalkingandtakingpictures1081080pmp4_coverr-friends-walk.mp4" type="video/mp4"></video>"""

            # format media
            if isinstance(note_by_toggle, ClozeAnkiNote):
                note_by_toggle.Extra = self.format_audio_video_tag(note_by_toggle.Extra)
            elif isinstance(note_by_toggle, StdAnkiNote):
                note_by_toggle.Back = self.format_audio_video_tag(note_by_toggle.Back)

        return note_by_toggle

    def _update_anki_note_field(self, note_by_toggle: BaseAnkiNote, anki_note: Note, model_name: str):
        model_fields = self.anki_api.modelFieldNames(model_name)
        # 根据 model 的字段名, 来更新
        for field_name in model_fields:
            anki_note[field_name] = getattr(note_by_toggle, field_name)

        # 更新 note 的 tags
        anki_note.tags = note_by_toggle.Tags if note_by_toggle.Tags else []

        # 这句留着在仅在 note 已经添加好的情况下使用
        if anki_note.id:
            self.anki_api.collection.update_note(anki_note)

    def create_new_anki_note(self, note_by_toggle, model_name) -> int:
        # 先更新 note 中的 media 信息
        note_by_toggle = self._update_media_info(note_by_toggle)
        # 获取 model 和cdeck_id 的名称
        try:
            model = self.anki_api.getModel(model_name)
        except Exception as e:
            raise e

        # 创建一个空的 note
        ankiNote = Note(self.anki_api.collection, model)
        # 将 note_by_toggle 中的信息填充到 ankiNote 中
        self._update_anki_note_field(note_by_toggle, ankiNote, model_name)
        # 将 ankiNote 添加到 deck 中
        try:
            ankiNoteId = self.add_anki_note_to_anki(ankiNote)
            self.logger.info("Note created: id=%s, front=%s", ankiNoteId, safe_str(note_by_toggle.Front))
        except Exception as e:
            raise e
        return ankiNoteId

    def update_exist_anki_note(self, ankinote_id, note_by_toggle, model_name) -> int:
        """note已经存在了, 且 note type name (i.e. model name) 也和model_name一致, 仅仅更新note的内容"""
        """
        :param ankinote_id: int
        :param note_by_toggle: BaseAnkiNote
        :param model_name: note_by_toggle所属的note type name
        """
        # 获取 note
        ankiNote = self.anki_api.getNote(ankinote_id)
        # 检查 note type 是否发生了变化
        model_id = self.anki_api.getModel(model_name)["id"]
        if ankiNote.mid != model_id:
            self.logger.warning(
                "Note type changed: note_id=%s, old=%s, new=%s",
                ankinote_id,
                ankiNote.mid,
                model_id,
            )
            raise Exception("Note type changed, please remove this note and create a new one.")
        # 先更新 note 中的 media 信息
        note_by_toggle = self._update_media_info(note_by_toggle)
        # 将 note_by_toggle 中的信息填充到 ankiNote 中
        self._update_anki_note_field(note_by_toggle, ankiNote, model_name)

        return ankiNote.id
