import base64
import enum
import glob
import hashlib
import os
import os.path
import re
import unicodedata
from typing import Optional

import anki
import anki.exporting
import anki.storage
import aqt
from anki.cards import Card
from anki.collection import Collection
from anki.consts import MODEL_CLOZE
from anki.errors import NotFoundError
from anki.media import MediaManager
from anki.notes import Note
from aqt.main import AnkiQt


class MediaType(enum.Enum):
    Audio = 1
    Video = 2
    Picture = 3


def download(url):
    client = anki.sync.AnkiRequestsClient()
    client.timeout = 10

    resp = client.get(url)
    if resp.status_code != 200:
        raise Exception("{} download failed with return code {}".format(url, resp.status_code))

    return client.streamContent(resp)


def cardQuestion(card):
    if getattr(card, "question", None) is None:
        return card._getQA()["q"]

    return card.question()


def cardAnswer(card):
    if getattr(card, "answer", None) is None:
        return card._getQA()["a"]

    return card.answer()


class AnkiConnect:
    def __init__(self, collection=None, window: Optional[AnkiQt] = None):
        self.collection: Collection = collection
        if collection is None:
            raise Exception("collection is not available")
            return
        self.window = window

    def save_model(self, models, ankiModel):
        models.update_dict(ankiModel)

    def is_run_inside_anki(self):
        """Check if the script is running inside Anki."""
        return self.window is not None

    def decks(self):
        decks = self.collection.decks
        if decks is None:
            raise Exception("decks are not available")

        return decks

    def scheduler(self):
        scheduler = self.collection.sched
        if scheduler is None:
            raise Exception("scheduler is not available")

        return scheduler

    def database(self):
        database = self.collection.db
        if database is None:
            raise Exception("database is not available")

        return database

    def media(self) -> MediaManager:
        media_manager = self.collection.media
        if media_manager is None:
            raise Exception("media is not available")

        return media_manager

    def getModel(self, modelName):
        """Get the model by name."""
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))
        return model

    def getField(self, model, fieldName):
        """Get the field in the model by field name.
        Parameters
        ----------
        model : dict
            The model dictionary.
        fieldName : str
            The field name.
        Returns
        -------
        dict
            The field dictionary.
        """
        fieldMap = self.collection.models.field_map(model)
        if fieldName not in fieldMap:
            raise Exception("field was not found in {}: {}".format(model["name"], fieldName))
        return fieldMap[fieldName][1]

    def getTemplate(self, model, templateName):
        """Get the template in the model by template name.
        Parameters
        ----------
        model : dict
            The model dictionary.
        templateName : str
            The template name.
        Returns
        -------
        dict
            The template dictionary.
        """
        for ankiTemplate in model["tmpls"]:
            if ankiTemplate["name"] == templateName:
                return ankiTemplate
        raise Exception("template was not found in {}: {}".format(model["name"], templateName))

    def startEditing(self):
        if self.is_run_inside_anki():
            self.window.requireReset()

    def noteCount(self):
        return self.collection.note_count()

    def createNote(self, note):
        collection = self.collection

        model = collection.models.by_name(note["modelName"])
        if model is None:
            raise Exception("model was not found: {}".format(note["modelName"]))

        deck = collection.decks.by_name(note["deckName"])
        if deck is None:
            raise Exception("deck was not found: {}".format(note["deckName"]))

        ankiNote = anki.notes.Note(collection, model)
        ankiNote.note_type()["did"] = deck["id"]
        if "tags" in note:
            ankiNote.tags = note["tags"]

        for name, value in note["fields"].items():
            for ankiName in ankiNote.keys():
                if name.lower() == ankiName.lower():
                    ankiNote[ankiName] = value
                    break

        self.addMediaFromNote(ankiNote, note)

        allowDuplicate = False
        duplicateScope = None
        duplicateScopeDeckName = None
        duplicateScopeCheckChildren = False
        duplicateScopeCheckAllModels = False

        if "options" in note:
            options = note["options"]
            if "allowDuplicate" in options:
                allowDuplicate = options["allowDuplicate"]
                if not isinstance(allowDuplicate, bool):
                    raise Exception('option parameter "allowDuplicate" must be boolean')
            if "duplicateScope" in options:
                duplicateScope = options["duplicateScope"]
            if "duplicateScopeOptions" in options:
                duplicateScopeOptions = options["duplicateScopeOptions"]
                if "deckName" in duplicateScopeOptions:
                    duplicateScopeDeckName = duplicateScopeOptions["deckName"]
                if "checkChildren" in duplicateScopeOptions:
                    duplicateScopeCheckChildren = duplicateScopeOptions["checkChildren"]
                    if not isinstance(duplicateScopeCheckChildren, bool):
                        raise Exception('option parameter "duplicateScopeOptions.checkChildren" must be boolean')
                if "checkAllModels" in duplicateScopeOptions:
                    duplicateScopeCheckAllModels = duplicateScopeOptions["checkAllModels"]
                    if not isinstance(duplicateScopeCheckAllModels, bool):
                        raise Exception('option parameter "duplicateScopeOptions.checkAllModels" must be boolean')

        duplicateOrEmpty = self.isNoteDuplicateOrEmptyInScope(
            ankiNote,
            deck,
            collection,
            duplicateScope,
            duplicateScopeDeckName,
            duplicateScopeCheckChildren,
            duplicateScopeCheckAllModels,
        )

        if duplicateOrEmpty == 1:
            raise Exception("cannot create note because it is empty")
        elif duplicateOrEmpty == 2:
            if allowDuplicate:
                return ankiNote
            raise Exception("cannot create note because it is a duplicate")
        elif duplicateOrEmpty == 0:
            return ankiNote
        else:
            raise Exception("cannot create note for unknown reason")

    def isNoteDuplicateOrEmptyInScope(
        self,
        note,
        deck,
        collection,
        duplicateScope,
        duplicateScopeDeckName,
        duplicateScopeCheckChildren,
        duplicateScopeCheckAllModels,
    ):
        # Returns: 1 if first is empty, 2 if first is a duplicate, 0 otherwise.

        # note.dupeOrEmpty returns if a note is a global duplicate with the specific model.
        # This is used as the default check, and the rest of this function is manually
        # checking if the note is a duplicate with additional options.
        if duplicateScope != "deck" and not duplicateScopeCheckAllModels:
            # note.dupeOrEmpty() returns 1 if the note is empty, 2 if it is a duplicate. check scope is global.
            return note.dupeOrEmpty() or 0

        # Primary field for uniqueness
        val = note.fields[0]
        if not val.strip():
            return 1
        csum = anki.utils.fieldChecksum(val)

        # Create dictionary of deck ids
        dids = None
        if duplicateScope == "deck":
            did = deck["id"]
            if duplicateScopeDeckName is not None:
                deck2 = collection.decks.by_name(duplicateScopeDeckName)
                if deck2 is None:
                    # Invalid deck, so cannot be duplicate
                    return 0
                did = deck2["id"]

            dids = {did: True}
            if duplicateScopeCheckChildren:
                for kv in collection.decks.children(did):
                    dids[kv[1]] = True

        # Build query
        query = "select id from notes where csum=?"
        queryArgs = [csum]
        if note.id:
            query += " and id!=?"
            queryArgs.append(note.id)
        if not duplicateScopeCheckAllModels:
            query += " and mid=?"
            queryArgs.append(note.mid)

        # Search
        for noteId in note.col.db.list(query, *queryArgs):
            if dids is None:
                # Duplicate note exists in the collection
                return 2
            # Validate that a card exists in one of the specified decks
            for cardDeckId in note.col.db.list("select did from cards where nid=?", noteId):
                if cardDeckId in dids:
                    return 2

        # Not a duplicate
        return 0

    def getCard(self, card_id: int) -> Card:
        try:
            return self.collection.getCard(card_id)
        except NotFoundError:
            raise NotFoundError("Card was not found: {}".format(card_id), None, None, None)  # noqa: B904

    def getNote(self, note_id: int) -> Note:
        try:
            return self.collection.get_note(note_id)  # api error
        except NotFoundError:
            raise NotFoundError("Note was not found: {}".format(note_id), None, None, None)  # noqa: B904

    def getNotesIdInDeck(self, deckName):
        """Get all notes id in the deck."""
        query = f'deck:"{deckName}"'
        res = self.findNotesByQuery(query)
        return set(res)

    def collectDeckTreeChildren(self, parent_node):
        allNodes = {parent_node.deck_id: parent_node}
        for child in parent_node.children:
            for deckId, childNode in self.collectDeckTreeChildren(child).items():
                allNodes[deckId] = childNode
        return allNodes

    #
    # Decks
    #

    def deckNames(self):
        """获取所有牌组的名称"""
        return [x.name for x in self.decks().all_names_and_ids()]

    def deckNamesAndIds(self):
        """获取所有牌组的名称和id"""
        decks = {}
        for deck in self.deckNames():
            decks[deck] = self.decks().id(deck)

        return decks

    def getDecks(self, cards):
        """获取所有牌组"""
        decks = {}
        for card in cards:
            did = self.database().scalar("select did from cards where id=?", card)
            deck = self.decks().get(did)["name"]
            if deck in decks:
                decks[deck].append(card)
            else:
                decks[deck] = [card]

        return decks

    def createDeck(self, deck):
        self.startEditing()
        return self.decks().id(deck)

    def changeDeck(self, cards, deck):
        """将卡片移动到指定牌组"""
        self.startEditing()

        did = self.collection.decks.id(deck)
        mod = anki.utils.intTime()
        usn = self.collection.usn()

        # normal cards
        scids = anki.utils.ids2str(cards)
        # remove any cards from filtered deck first
        self.collection.sched.remFromDyn(cards)

        # then move into new deck
        self.collection.db.execute(
            "update cards set usn=?, mod=?, did=? where id in " + scids,
            usn,
            mod,
            did,
        )

    def deleteDecks(self, decks, cardsToo=False):
        """删除牌组
        Parameters
        ----------
        decks : list
            要删除的牌组名称列表
        cardsToo : bool, optional
            是否同时删除牌组中的卡片, by default False
        """
        if not cardsToo:
            # since f592672fa952260655881a75a2e3c921b2e23857 (2.1.28)
            # (see anki$ git log "-Gassert cardsToo")
            # you can't delete decks without deleting cards as well.
            # however, since 62c23c6816adf912776b9378c008a52bb50b2e8d (2.1.45)
            # passing cardsToo to `rem` (long deprecated) won't raise an error!
            # this is dangerous, so let's raise our own exception
            raise Exception("Since Anki 2.1.28 it's not possible " "to delete decks without deleting cards as well")
        self.startEditing()
        decks = filter(lambda d: d in self.deckNames(), decks)
        for deck in decks:
            did = self.decks().id(deck)
            self.decks().remove([did])

    def getDeckConfig(self, deck):
        if deck not in self.deckNames():
            return False

        collection = self.collection
        did = collection.decks.id(deck)
        return collection.decks.config_dict_for_deck_id(did)

    def saveDeckConfig(self, config):
        collection = self.collection

        config["id"] = str(config["id"])
        config["mod"] = anki.utils.intTime()
        config["usn"] = collection.usn()
        if int(config["id"]) not in [c["id"] for c in collection.decks.all_config()]:
            return False
        try:
            collection.decks.save(config)
            collection.decks.update_config(config)
        except:  # noqa: E722
            return False
        return True

    def setDeckConfigId(self, decks, configId):
        configId = int(configId)
        for deck in decks:
            if deck not in self.deckNames():
                return False

        collection = self.collection

        for deck in decks:
            try:
                did = str(collection.decks.id(deck))
                deck_dict = aqt.mw.col.decks.decks[did]
                deck_dict["conf"] = configId
                collection.decks.save(deck_dict)
            except:  # noqa: E722
                return False

        return True

    def cloneDeckConfigId(self, name, cloneFrom="1"):
        configId = int(cloneFrom)
        collection = self.collection
        if configId not in [c["id"] for c in collection.decks.all_config()]:
            return False

        config = collection.decks.get_config(configId)
        return collection.decks.add_config_returning_id(name, config)

    def removeDeckConfigId(self, configId):
        collection = self.collection
        if int(configId) not in [c["id"] for c in collection.decks.all_config()]:
            return False

        collection.decks.remove_config(configId)
        return True

    def storeMediaFile(
        self,
        filename,
        data=None,
        path=None,
        url=None,
        skipHash=None,
        deleteExisting=True,
    ) -> str:
        """
        Store a media file in the media folder.
        Parameters
        ----------
        filename : str
            The name of the file.
        data : str, optional
            The base64 encoded data of the file, by default None.
        path : str, optional
            The path to the file, by default None.
        url : str, optional
            The URL to download the file from, by default None.
        skipHash : str, optional
            The hash to skip the file if it already exists, by default None.
        deleteExisting : bool, optional
            Whether to delete the existing file, by default True.
        Returns
        -------
        str
            The filename of the stored file.

        """
        if not (data or path or url):
            raise Exception('You must provide a "data", "path", or "url" field.')
        if data:
            mediaData = base64.b64decode(data)
        elif path:
            with open(path, "rb") as f:
                mediaData = f.read()
        elif url:
            mediaData = download(url)

        if skipHash is None:
            skip = False
        else:
            m = hashlib.md5()
            m.update(mediaData)
            skip = skipHash == m.hexdigest()

        if skip:
            return None
        if deleteExisting:
            self.deleteMediaFile(filename)
        return self.media().write_data(filename, mediaData)

    def retrieveMediaFile(self, filename):
        filename = os.path.basename(filename)
        filename = unicodedata.normalize("NFC", filename)
        filename = self.media().stripIllegal(filename)

        path = os.path.join(self.media().dir(), filename)
        if os.path.exists(path):
            with open(path, "rb") as file:
                return base64.b64encode(file.read()).decode("ascii")

        return False

    def hasMediaFile(self, filename):
        return self.media().have(filename)

    def getMediaFilesNames(self, pattern="*"):
        path = os.path.join(self.media().dir(), pattern)
        return [os.path.basename(p) for p in glob.glob(path)]

    def deleteMediaFile(self, filename):
        self.media().trash_files([filename])

    def getMediaDirPath(self):
        return os.path.abspath(self.media().dir())

    def addNote(self, note):
        ankiNote = self.createNote(note)

        collection = self.collection
        self.startEditing()
        nCardsAdded = collection.add_note(ankiNote)  # api error
        if nCardsAdded < 1:
            raise Exception("The field values you have provided would make an empty question on all cards.")
        collection.autosave()

        return ankiNote.id

    def addMediaFromNote(self, ankiNote, note):
        audioObjectOrList = note.get("audio")
        self.addMedia(ankiNote, audioObjectOrList, MediaType.Audio)

        videoObjectOrList = note.get("video")
        self.addMedia(ankiNote, videoObjectOrList, MediaType.Video)

        pictureObjectOrList = note.get("picture")
        self.addMedia(ankiNote, pictureObjectOrList, MediaType.Picture)

    def addMedia(self, ankiNote, mediaObjectOrList, mediaType):
        if mediaObjectOrList is None:
            return

        if isinstance(mediaObjectOrList, list):
            mediaList = mediaObjectOrList
        else:
            mediaList = [mediaObjectOrList]

        for media in mediaList:
            if media is not None and len(media["fields"]) > 0:
                try:
                    mediaFilename = self.storeMediaFile(
                        media["filename"],
                        data=media.get("data"),
                        path=media.get("path"),
                        url=media.get("url"),
                        skipHash=media.get("skipHash"),
                        deleteExisting=media.get("deleteExisting"),
                    )

                    if mediaFilename is not None:
                        for field in media["fields"]:
                            if field in ankiNote:
                                if mediaType is MediaType.Picture:
                                    ankiNote[field] += '<img src="{}">'.format(mediaFilename)
                                elif mediaType is MediaType.Audio or mediaType is MediaType.Video:
                                    ankiNote[field] += "[sound:{}]".format(mediaFilename)

                except Exception as e:
                    errorMessage = str(e).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    for field in media["fields"]:
                        if field in ankiNote:
                            ankiNote[field] += errorMessage

    def canAddNote(self, note):
        try:
            return bool(self.createNote(note))
        except:  # noqa: E722
            return False

    def canAddNoteWithErrorDetail(self, note):
        try:
            return {"canAdd": bool(self.createNote(note))}
        except Exception as e:
            return {"canAdd": False, "error": str(e)}

    def updateNoteFields(self, note):
        ankiNote = self.getNote(note["id"])

        self.startEditing()
        for name, value in note["fields"].items():
            if name in ankiNote:
                ankiNote[name] = value

        audioObjectOrList = note.get("audio")
        self.addMedia(ankiNote, audioObjectOrList, MediaType.Audio)

        videoObjectOrList = note.get("video")
        self.addMedia(ankiNote, videoObjectOrList, MediaType.Video)

        pictureObjectOrList = note.get("picture")
        self.addMedia(ankiNote, pictureObjectOrList, MediaType.Picture)

        ankiNote.flush()

        self.collection.autosave()

    def updateNote(self, note):
        updated = False
        if "fields" in note.keys():
            self.updateNoteFields(note)
            updated = True
        if "tags" in note.keys():
            self.updateNoteTags(note["id"], note["tags"])
            updated = True
        if not updated:
            raise Exception('Must provide a "fields" or "tags" property.')

    def updateNoteModel(self, note):
        """
        Update the model and fields of a given note.

        :param note: A dictionary containing note details, including 'id', 'modelName', 'fields', and 'tags'.
        """
        # Extract and validate the note ID
        note_id = note.get("id")
        if not note_id:
            raise ValueError("Note ID is required")

        # Extract and validate the new model name
        new_model_name = note.get("modelName")
        if not new_model_name:
            raise ValueError("Model name is required")

        # Extract and validate the new fields
        new_fields = note.get("fields")
        if not new_fields or not isinstance(new_fields, dict):
            raise ValueError("Fields must be provided as a dictionary")

        # Extract the new tags
        new_tags = note.get("tags", [])

        # Get the current note from the collection
        anki_note = self.getNote(note_id)

        # Get the new model from the collection
        collection = self.collection
        new_model = collection.models.by_name(new_model_name)
        if not new_model:
            raise ValueError(f"Model '{new_model_name}' not found")

        # Update the note's model
        anki_note.mid = new_model["id"]
        anki_note._fmap = collection.models.field_map(new_model)
        anki_note.fields = [""] * len(new_model["flds"])

        # Update the fields with new values
        for name, value in new_fields.items():
            for anki_name in anki_note.keys():
                if name.lower() == anki_name.lower():
                    anki_note[anki_name] = value
                    break

        # Update the tags
        anki_note.tags = new_tags

        # Flush changes to ensure they are saved
        anki_note.flush()

        # Save changes to the collection
        collection.autosave()

    def updateNoteTags(self, note, tags):
        if isinstance(tags, str):
            tags = [tags]
        if not isinstance(tags, list) or not all([isinstance(t, str) for t in tags]):
            raise Exception("Must provide tags as a list of strings")

        for old_tag in self.getNoteTags(note):
            self.removeTags([note], old_tag)
        for new_tag in tags:
            self.addTags([note], new_tag)

    def getNoteTags(self, note):
        return self.getNote(note).tags

    def addTags(self, notes, tags, add=True):
        self.startEditing()
        self.collection.tags.bulkAdd(notes, tags, add)

    def removeTags(self, notes, tags):
        return self.addTags(notes, tags, False)

    def getTags(self):
        return self.collection.tags.all()

    def clearUnusedTags(self):
        self.collection.tags.registerNotes()

    def replaceTags(self, notes, tag_to_replace, replace_with_tag):
        if self.is_run_inside_anki():
            self.window.progress.start()

        for nid in notes:
            try:
                note = self.getNote(nid)
            except NotFoundError:
                continue

            if note.has_tag(tag_to_replace):
                note.remove_tag(tag_to_replace)
                note.add_tag(replace_with_tag)
                note.flush()
        if self.is_run_inside_anki():
            self.window.requireReset()
            self.window.progress.finish()
            self.window.reset()

    def replaceTagsInAllNotes(self, tag_to_replace, replace_with_tag):
        if self.is_run_inside_anki():
            self.window.progress.start()

        collection = self.collection
        for nid in collection.db.list("select id from notes"):
            note = self.getNote(nid)
            if note.has_tag(tag_to_replace):
                note.remove_tag(tag_to_replace)
                note.add_tag(replace_with_tag)
                note.flush()
        if self.is_run_inside_anki():
            self.window.requireReset()
            self.window.progress.finish()
            self.window.reset()

    def setEaseFactors(self, cards, easeFactors):
        couldSetEaseFactors = []
        for i, card in enumerate(cards):
            try:
                ankiCard = self.getCard(card)
            except NotFoundError:
                couldSetEaseFactors.append(False)
                continue

            couldSetEaseFactors.append(True)
            ankiCard.factor = easeFactors[i]
            ankiCard.flush()

        return couldSetEaseFactors

    def setSpecificValueOfCard(self, card, keys, newValues, warning_check=False):
        if isinstance(card, list):
            print("card has to be int, not list")
            return False

        if not isinstance(keys, list) or not isinstance(newValues, list):
            print("keys and newValues have to be lists.")
            return False

        if len(newValues) != len(keys):
            print("Invalid list lengths.")
            return False

        for key in keys:
            if key in [
                "did",
                "id",
                "ivl",
                "lapses",
                "left",
                "mod",
                "nid",
                "odid",
                "odue",
                "ord",
                "queue",
                "reps",
                "type",
                "usn",
            ]:
                if warning_check is False:
                    return False

        result = []
        try:
            ankiCard = self.getCard(card)
            for i, key in enumerate(keys):
                setattr(ankiCard, key, newValues[i])
            ankiCard.flush()
            result.append(True)
        except Exception as e:
            result.append([False, str(e)])
        return result

    #
    # Models
    #

    def modelAll(self):
        """返回所有model的具体详细信息"""
        return self.collection.models.all()

    def modelNames(self):
        return [n.name for n in self.collection.models.all_names_and_ids()]

    def removModelByModelId(self, modelId):
        self.collection.models.remove(modelId)

    def removModelByModelName(self, modelName):
        model = self.collection.models.by_name(modelName)
        if model is not None:
            self.removModelByModelId(model["id"])

    def createModel(self, modelName, inOrderFields, cardTemplates, css=None, isCloze=False):
        # https://github.com/dae/anki/blob/b06b70f7214fb1f2ce33ba06d2b095384b81f874/anki/stdmodels.py
        if len(inOrderFields) == 0:
            raise Exception("Must provide at least one field for inOrderFields")
        if len(cardTemplates) == 0:
            raise Exception("Must provide at least one card for cardTemplates")
        if modelName in [n.name for n in self.collection.models.all_names_and_ids()]:
            raise Exception("Model name already exists")

        collection = self.collection
        mm = collection.models

        # Generate new Note
        m = mm.new(modelName)
        if isCloze:
            m["type"] = MODEL_CLOZE

        # Create fields and add them to Note
        for field in inOrderFields:
            fm = mm.new_field(field)
            mm.addField(m, fm)

        # Add shared css to model if exists. Use default otherwise
        if css is not None:
            m["css"] = css

        # Generate new card template(s)
        cardCount = 1
        for card in cardTemplates:
            cardName = "Card " + str(cardCount)
            if "Name" in card:
                cardName = card["Name"]

            t = mm.new_template(cardName)
            cardCount += 1
            t["qfmt"] = card["Front"]
            t["afmt"] = card["Back"]
            mm.addTemplate(m, t)

        mm.add(m)
        return m

    def modelNamesAndIds(self):
        models = {}
        for model in self.modelNames():
            models[model] = int(self.collection.models.by_name(model)["id"])

        return models

    def findModelsById(self, modelIds):
        models = []
        for id in modelIds:
            model = self.collection.models.get(id)
            if model is None:
                raise Exception("model was not found: {}".format(id))
            else:
                models.append(model)
        return models

    def findModelsByName(self, modelNames):
        models = []
        for name in modelNames:
            model = self.collection.models.by_name(name)
            if model is None:
                raise Exception("model was not found: {}".format(name))
            else:
                models.append(model)
        return models

    def modelNameFromId(self, modelId):
        model = self.collection.models.get(modelId)
        if model is None:
            raise Exception("model was not found: {}".format(modelId))
        else:
            return model["name"]

    def modelFieldNames(self, modelName) -> list[str]:
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))
        else:
            return [field["name"] for field in model["flds"]]

    def modelFieldDescriptions(self, modelName):
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))
        else:
            try:
                return [field["description"] for field in model["flds"]]
            except KeyError:
                # older versions of Anki don't have field descriptions
                return ["" for field in model["flds"]]

    def modelFieldFonts(self, modelName):
        model = self.getModel(modelName)

        fonts = {}
        for field in model["flds"]:
            fonts[field["name"]] = {
                "font": field["font"],
                "size": field["size"],
            }

        return fonts

    def modelFieldsOnTemplates(self, modelName):
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))

        templates = {}
        for template in model["tmpls"]:
            fields = []
            for side in ["qfmt", "afmt"]:
                fieldsForSide = []

                # based on _fieldsOnTemplate from aqt/clayout.py
                matches = re.findall("{{[^#/}]+?}}", template[side])
                for match in matches:
                    # remove braces and modifiers
                    match = re.sub(r"[{}]", "", match)
                    match = match.split(":")[-1]

                    # for the answer side, ignore fields present on the question side + the FrontSide field
                    if match == "FrontSide" or side == "afmt" and match in fields[0]:
                        continue
                    fieldsForSide.append(match)

                fields.append(fieldsForSide)

            templates[template["name"]] = fields

        return templates

    def modelTemplates(self, modelName):
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))

        templates = {}
        for template in model["tmpls"]:
            templates[template["name"]] = {
                "Front": template["qfmt"],
                "Back": template["afmt"],
            }

        return templates

    def modelStyling(self, modelName):
        model = self.collection.models.by_name(modelName)
        if model is None:
            raise Exception("model was not found: {}".format(modelName))

        return {"css": model["css"]}

    def updateModelTemplates(self, model):
        models = self.collection.models
        ankiModel = models.by_name(model["name"])
        if ankiModel is None:
            raise Exception("model was not found: {}".format(model["name"]))

        templates = model["templates"]
        for ankiTemplate in ankiModel["tmpls"]:
            template = templates.get(ankiTemplate["name"])
            if template:
                qfmt = template.get("Front")
                if qfmt:
                    ankiTemplate["qfmt"] = qfmt

                afmt = template.get("Back")
                if afmt:
                    ankiTemplate["afmt"] = afmt

        self.save_model(models, ankiModel)

    def updateModelStyling(self, model):
        models = self.collection.models
        ankiModel = models.by_name(model["name"])
        if ankiModel is None:
            raise Exception("model was not found: {}".format(model["name"]))

        ankiModel["css"] = model["css"]

        self.save_model(models, ankiModel)

    def findAndReplaceInModels(self, modelName, findText, replaceText, front=True, back=True, css=True):
        if not modelName:
            ankiModel = self.collection.models.allNames()
        else:
            model = self.collection.models.by_name(modelName)
            if model is None:
                raise Exception("model was not found: {}".format(modelName))
            ankiModel = [modelName]
        updatedModels = 0
        for model in ankiModel:
            model = self.collection.models.by_name(model)
            checkForText = False
            if css and findText in model["css"]:
                checkForText = True
                model["css"] = model["css"].replace(findText, replaceText)
            for tmpls in model.get("tmpls"):
                if front and findText in tmpls["qfmt"]:
                    checkForText = True
                    tmpls["qfmt"] = tmpls["qfmt"].replace(findText, replaceText)
                if back and findText in tmpls["afmt"]:
                    checkForText = True
                    tmpls["afmt"] = tmpls["afmt"].replace(findText, replaceText)
            self.save_model(self.collection.models, model)
            if checkForText:
                updatedModels += 1
        return updatedModels

    def modelTemplateRename(self, modelName, oldTemplateName, newTemplateName):
        mm = self.collection.models
        model = self.getModel(modelName)
        ankiTemplate = self.getTemplate(model, oldTemplateName)

        ankiTemplate["name"] = newTemplateName
        self.save_model(mm, model)

    def modelTemplateReposition(self, modelName, templateName, index):
        mm = self.collection.models
        model = self.getModel(modelName)
        ankiTemplate = self.getTemplate(model, templateName)

        mm.reposition_template(model, ankiTemplate, index)
        self.save_model(mm, model)

    def modelTemplateAdd(self, modelName, template):
        # "Name", "Front", "Back" borrows from `createModel`
        mm = self.collection.models
        model = self.getModel(modelName)
        name = template["Name"]
        qfmt = template["Front"]
        afmt = template["Back"]

        # updates the template if it already exists
        for ankiTemplate in model["tmpls"]:
            if ankiTemplate["name"] == name:
                ankiTemplate["qfmt"] = qfmt
                ankiTemplate["afmt"] = afmt
                return

        ankiTemplate = mm.new_template(name)
        ankiTemplate["qfmt"] = qfmt
        ankiTemplate["afmt"] = afmt
        mm.add_template(model, ankiTemplate)

        self.save_model(mm, model)

    def modelTemplateRemove(self, modelName, templateName):
        mm = self.collection.models
        model = self.getModel(modelName)
        ankiTemplate = self.getTemplate(model, templateName)

        mm.remove_template(model, ankiTemplate)
        self.save_model(mm, model)

    def modelFieldRename(self, modelName, oldFieldName, newFieldName):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, oldFieldName)

        mm.renameField(model, field, newFieldName)

        self.save_model(mm, model)

    def modelFieldReposition(self, modelName, fieldName, index):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, fieldName)

        mm.reposition_field(model, field, index)

        self.save_model(mm, model)

    def modelFieldAdd(self, modelName, fieldName, index=None):
        mm = self.collection.models
        model = self.getModel(modelName)

        # only adds the field if it doesn't already exist
        fieldMap = mm.field_map(model)
        if fieldName not in fieldMap:
            field = mm.new_field(fieldName)
            mm.addField(model, field)

        # repositions, even if the field already exists
        if index is not None:
            fieldMap = mm.field_map(model)
            newField = fieldMap[fieldName][1]
            mm.reposition_field(model, newField, index)

        self.save_model(mm, model)

    def modelFieldRemove(self, modelName, fieldName):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, fieldName)

        mm.remove_field(model, field)

        self.save_model(mm, model)

    def modelFieldSetFont(self, modelName, fieldName, font):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, fieldName)

        if not isinstance(font, str):
            raise Exception("font should be a string: {}".format(font))

        field["font"] = font

        self.save_model(mm, model)

    def modelFieldSetFontSize(self, modelName, fieldName, fontSize):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, fieldName)

        if not isinstance(fontSize, int):
            raise Exception("fontSize should be an integer: {}".format(fontSize))

        field["size"] = fontSize

        self.save_model(mm, model)

    def modelFieldSetDescription(self, modelName, fieldName, description):
        mm = self.collection.models
        model = self.getModel(modelName)
        field = self.getField(model, fieldName)

        if not isinstance(description, str):
            raise Exception("description should be a string: {}".format(description))

        if "description" in field:  # older versions do not have the 'description' key
            field["description"] = description
            self.save_model(mm, model)
            return True
        return False

    def deckNameFromId(self, deckId):
        deck = self.collection.decks.get(deckId)
        if deck is None:
            raise Exception("deck was not found: {}".format(deckId))

        return deck["name"]

    def findNotesByQuery(self, query=None):
        if query is None:
            return []

        return list(map(int, self.collection.find_notes(query)))

    def findCardsByQuery(self, query=None):
        if query is None:
            return []

        return list(map(int, self.collection.find_cards(query)))

    def cardsInfo(self, cards):
        """根据卡片id获取卡片的详细信息
        Parameters
        ----------
        cards : list
            卡片id列表
        Returns
        -------
        list
            卡片详细信息列表
        """
        result = []
        for cid in cards:
            try:
                card = self.getCard(cid)
                model = card.note_type()
                note = card.note()
                fields = {}
                for info in model["flds"]:
                    order = info["ord"]
                    name = info["name"]
                    fields[name] = {
                        "value": note.fields[order],
                        "order": order,
                    }

                result.append(
                    {
                        "cardId": card.id,
                        "fields": fields,
                        "fieldOrder": card.ord,
                        "question": cardQuestion(card),
                        "answer": cardAnswer(card),
                        "modelName": model["name"],
                        "ord": card.ord,
                        "deckName": self.deckNameFromId(card.did),
                        "css": model["css"],
                        "factor": card.factor,
                        # This factor is 10 times the ease percentage,
                        # so an ease of 310% would be reported as 3100
                        "interval": card.ivl,
                        "note": card.nid,
                        "type": card.type,
                        "queue": card.queue,
                        "due": card.due,
                        "reps": card.reps,
                        "lapses": card.lapses,
                        "left": card.left,
                        "mod": card.mod,
                    }
                )
            except NotFoundError:
                # Anki will give a NotFoundError if the card ID does not exist.
                # Best behavior is probably to add an 'empty card' to the
                # returned result, so that the items of the input and return
                # lists correspond.
                result.append({})

        return result

    def reloadCollection(self):
        self.collection.reset()

    #
    # Notes
    #

    def deleteNotes(self, notes):
        self.collection.remove_notes(notes)

    def removeEmptyNotes(self):
        for model in self.collection.models.all():
            if self.collection.models.use_count(model) == 0:
                self.collection.models.remove(model["id"])
        self.window.requireReset()

    def cardsToNotes(self, cards):
        return self.collection.db.list("select distinct nid from cards where id in " + anki.utils.ids2str(cards))

    def guiCheckDatabase(self):
        if self.is_run_inside_anki():
            self.window.onCheckDB()
        return True

    def addNotes(self, notes):
        results = []
        for note in notes:
            try:
                results.append(self.addNote(note))
            except:  # noqa: E722
                results.append(None)

        return results

    def canAddNotes(self, notes):
        results = []
        for note in notes:
            results.append(self.canAddNote(note))

        return results

    def canAddNotesWithErrorDetail(self, notes):
        results = []
        for note in notes:
            results.append(self.canAddNoteWithErrorDetail(note))

        return results
