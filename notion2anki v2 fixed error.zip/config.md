# Configuration
**Please try to avoid using this setting, prefer to set it from Tools -> Notion2Anki -> Setting**

- `debug`: `bool [default: false]` — enable debug logging to file.
- `user_email`: `str [default: None]` — User email for [Notion2Anki](www.notion2anki.com).
- `user_passward`: `str [default: None]` — The password for the user email.
- `sync_every_minutes`: `int [default: 30]` — auto sync interval in minutes. Set to 0 to disable auto sync.
- `notion_token`: `str [default: None]` — Notion APIv2 token.
- `notion_namespace`: `str [default: None]` — Notion namespace (your username) to form source URLs.
- `notion_pages`: `array [default: [] ]` — List of Notion pages to export notes from.
  - `page_id`: 32 chars of Notion page id.,
  - `recursive`: If true, Page should be exported with all its subpages, note that this require notion plus subscription.
  - `target_deck`: The target deck is a string attribute that specifies the name of the deck where loaded notes will be added. If multiple page_ids refer to the same target_deck, their corresponding notes will be combined and added to the same target_deck.
  - `absolute_update`: `bool [default: false]`- If true, the notes will be updated in the target deck with the same note as the notion page, and the note that is already in the target deck but not in the notion page will be deleted. 
  - `incremental_update`: `bool [default: false]`: If true, only new notion notes will be added to the target deck, and the note that is already in the target deck but not in the notion page will not not be deleted.

You can not set `incremental_update` and `absolute_update` to true at the same time.

## Notion token

To get **Notion API token**, log in to Notion via a browser (assuming Chrome here),
then press `Ctrl+Shift+I` to open Developer Tools, go to the "Application" tab
and find `token_v2` under Cookie on the left.

## Notion pages

To get **Notion page id**, open up the page in a browser and look at the
address bar. 32 chars of gibberish after a page title is the page id:
`https://www.notion.so/notion_user/My-Learning-Book-8a775ee482ab43732abc9319add819c5`
➡ `8a775ee482ab43732abc9319add819c5`.

Parameter `recursice` indicates whether page should include its subpages. Note that this require notion plus subscription.
