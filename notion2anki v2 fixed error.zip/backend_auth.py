"""User class for authentication."""

from __future__ import annotations

import datetime
import time

import requests

from .helpers import get_logger


class UnvalidEmailOrPassword(Exception):
    """Unvalid email or password."""


class BackendServerError(Exception):
    """Backend server error."""


class ExpiredToken(Exception):
    """Expired token."""


class UserInfo:
    def __init__(
        self, email: str, username: str, confirmed_time: str, created_time: str, redeem_expire_time: str
    ) -> None:
        self.confirmed_time: str = confirmed_time
        self.created_time: str = created_time
        self.email: str = email
        self.username: str = username
        self.redeem_expire_time: str = redeem_expire_time

    @property
    def redeemed(self):
        # 判断 utc 的redeemed_expire_time 是否大于当前utc时间
        return datetime.datetime.now(datetime.timezone.utc) <= datetime.datetime.strptime(
            self.redeem_expire_time, "%Y-%m-%d %H:%M:%S"
        ).replace(tzinfo=datetime.timezone.utc)

    def __str__(self) -> str:
        return f"User: {self.username}, Email: {self.email}, ExpireTime: {self.redeem_expire_time}, Redeemed: {self.redeemed}"


class User:
    BACKEND_HOST = "https://www.notion2anki.com"
    # BACKEND_HOST = "http://127.0.0.1:5000"
    GET_USER_API = f"{BACKEND_HOST}/api/get_user"
    SIGNIN_API = f"{BACKEND_HOST}/api/signin"
    SIGNOUT_API = f"{BACKEND_HOST}/api/signout"
    REFRESH_API = f"{BACKEND_HOST}/api/refresh"
    CONVERSION_RECORD_API = f"{BACKEND_HOST}/api/conversion_record"
    LAST_CONVERSION_RECORD_API = f"{BACKEND_HOST}/api/last_conversion"
    POST_CONVERSION_RECORD_API = f"{BACKEND_HOST}/api/conversion_record"

    def __init__(self, email: str = "", password: str = "", debug: bool = False) -> None:
        """Init the user.

        :param email: email
        :param password: password
        :param debug: debug mode
        """
        self.logger = get_logger(self.__class__.__name__, debug)
        self.access_token = None
        self.refresh_token = None
        self.email = email
        self.password = password

    def update_user(self, email: str, password: str) -> None:
        """Update user info.

        :param email: email
        :param password: password
        """
        self.email = email
        self.password = password

    def get_jwt(self):
        """Get JWT token.
        401: "message": "Wrong password"
        401: "message": "User not found"
        """
        try:
            response = requests.post(self.SIGNIN_API, json={"email": self.email, "password": self.password})
            rsp_json = response.json()
            response.raise_for_status()

        except requests.HTTPError as e:
            if response.status_code == 401:
                self.logger.error(f"Unvalid email:{self.email} or password:{self.password}. {e}")
                raise UnvalidEmailOrPassword(rsp_json["msg"]) from e
            elif response.status_code == 500:
                self.logger.error(f"Backend server error: {e}")
                raise BackendServerError("Backend server error (500)") from e
        except requests.RequestException as e:
            self.logger.error(f"Cannot get JWT token: {e}")
            raise e

        self.access_token = rsp_json["access_token"]
        self.refresh_token = rsp_json["refresh_token"]

    def refresh_jwt(self) -> str:
        """Refresh JWT token
        422: "msg": "Signature verification failed"
        """
        try:
            headers = {"Authorization ": f"Bearer {self.refresh_token}"}
            response = requests.post(self.REFRESH_API, headers=headers)
            response.raise_for_status()
        except requests.HTPError as e:
            if response.status_code == 422:
                self.logger.error("Signature verification failed")
                raise ExpiredToken(response.json()["msg"]) from e
            else:
                self.logger.error(f"Cannot refresh JWT token: {e}")
                raise BackendServerError(f"Backend server error {response.status_code}") from e
        except requests.RequestException as e:
            self.logger.error(f"Cannot refresh JWT token: {e}")
            raise e

        self.access_token = response.json()["access_token"]  # 更新 access_token

    def signout(self) -> None:
        """Sign out."""
        raise NotImplementedError

    def _get_user(self) -> dict:
        """Get user info.

        :returns: user info
        """
        headers = {"Authorization": f"Bearer {self.access_token}"}
        try:
            s = time.time()
            response = requests.post(self.GET_USER_API, headers=headers)
            print("get_user_only request", time.time() - s)
            resp_json = response.json()
            response.raise_for_status()
        except requests.HTTPError as e:
            if response.status_code == 422:
                self.logger.error("Signature verification failed")
                raise ExpiredToken(resp_json["msg"]) from e
            else:
                self.logger.error(f"Cannot get user info: {e}")
                raise BackendServerError(f"Backend server error {response.status_code}") from e
        except requests.RequestException as e:
            self.logger.error(f"Cannot get user info: {e}")
            raise e
        return response.json()

    def get_user(self) -> dict:
        """Get user info.

        :returns: user info
        """
        # 如果没有 access_token，先获取 access_token
        if self.access_token is None:
            try:
                self.get_jwt()
            except UnvalidEmailOrPassword as e:
                raise e
            except requests.RequestException as e:
                self.logger.error(f"Cannot get jwt: {e}")
                raise e
            self.logger.info("Get JWT token success")

            try:
                user_info = self._get_user()
            except Exception as e:
                self.logger.error(f"Cannot get user info: {e}")
                raise e

        # 有 access_token后，获取用户信息，此时可以保证的是 用户名、密码是正确的
        else:
            try:
                user_info = self._get_user()
            except Exception as e:
                self.logger.error(f"Cannot get user info: {e}")
                raise e

            user_info = self._get_user()

        return UserInfo(**user_info)

    def get_conversion_record(self):
        """Get conversion records.
        422: "msg": "Signature verification failed""
        """
        # 先获取 access_token
        headers = {"Authorization": f"Bearer {self.access_token}"}
        try:
            response = requests.get(self.CONVERSION_RECORD_API, headers=headers)
            response.raise_for_status()
        except requests.HTTPError as e:
            if response.status_code == 422:
                self.logger.error("Token has expired, try to refresh token")
                try:
                    self.refresh_jwt()
                except Exception:
                    self.get_jwt()
                return self.get_conversion_record()
            else:
                self.logger.error(f"Cannot get conversion records: {e}")
                raise BackendServerError(f"Backend server error {response.status_code}") from e
        except requests.RequestException as e:
            raise e

        return response.json()

    def get_last_conversion(self):
        """Get last conversion record."""
        headers = {"Authorization": f"Bearer {self.access_token}"}
        try:
            response = requests.get(self.LAST_CONVERSION_RECORD_API, headers=headers)
            response.raise_for_status()
        except requests.HTTPError as e:
            if response.status_code == 422:
                self.logger.error("Token has expired, try to refresh token")
                try:
                    self.refresh_jwt()
                except Exception:
                    self.get_jwt()
                return self.get_last_conversion_record()
            else:
                self.logger.error(f"Cannot get last_conversion records: {e}")
                raise BackendServerError(f"Backend server error {response.status_code}") from e
        except requests.RequestException as e:
            raise e

        return response.json()

    def post_conversion_record(self, record):
        headers = {"Authorization": f"Bearer {self.access_token}"}

        try:
            response = requests.post(self.POST_CONVERSION_RECORD_API, headers=headers, json=record)
            response.raise_for_status()
        except Exception as e:
            raise e

        return
