"""Parser to extract Anki note data from HTML."""

from dataclasses import dataclass
from typing import List

from .toggle_parser import MediaInToggle, ToggleDetails


@dataclass
class BaseAnkiNote:
    """Base Anki Note"""

    Front: str
    NotionLink: str
    ToggleLink: str
    Tags: List[str]
    Medias: List[MediaInToggle]


@dataclass
class StdAnkiNote(BaseAnkiNote):
    """standard anki note"""

    Back: str


@dataclass
class ClozeAnkiNote(BaseAnkiNote):
    """cloze anki note"""

    Extra: str


def construct_anki_note_from_toggle(toggle: ToggleDetails) -> BaseAnkiNote:
    """从 ToggleDetails 中构造 BaseAnkiNote
    目前仅有两种类型的卡片, 一种是 cloze 类型, 一种是 standard 类型, 这两种类型的区别在于Back字段和Extra字段"""
    if toggle.is_cloze:
        return ClozeAnkiNote(
            Front=toggle.summary,
            Extra=toggle.content,
            NotionLink=toggle.page_src,
            ToggleLink=toggle.toggle_src,
            Tags=toggle.tags,
            Medias=toggle.medias,
        )
    else:
        return StdAnkiNote(
            Front=toggle.summary,
            Back=toggle.content,
            NotionLink=toggle.page_src,
            ToggleLink=toggle.toggle_src,
            Tags=toggle.tags,
            Medias=toggle.medias,
        )
